# AutoTube on iPhone 12 (Safari)

AutoTube is a Python/Gradio app. It cannot be installed as a native iOS app from this ZIP. Run it on a cloud host (or a computer that stays online), then open its HTTPS URL in Safari and add it to the Home Screen.

## Easiest hosted route (Render)
1. Upload this project to a GitHub repository (the ZIP itself can be extracted first).
2. Create a **Web Service** on Render and connect the repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `python app.py`
5. Set the service to use Python 3.10 or newer. The app listens on port 7860; for Render, use the platform's `$PORT` (see `render.yaml` / `app.py` configuration).
6. Wait for deployment, then open the generated `https://....onrender.com` address in Safari on iPhone.
7. Safari → Share → **Add to Home Screen** → Add.

## Notes
- Cloud rendering uses server CPU/RAM and can be slow or have host limits. Long videos may need a paid host with sufficient memory/storage.
- Never put provider API keys in a public repository. Enter them only in the app's password field; production secrets should be configured securely.
- The app is not deployed by this package. You need a hosting account and must complete deployment.
