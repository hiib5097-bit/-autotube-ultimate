"""Reusable keyframed motion paths for characters and props."""
import math
def interpolate(a,b,u):
    return a+(b-a)*u
def keyframes_value(keys,t):
    keys=sorted(keys,key=lambda x:x[0])
    if t<=keys[0][0]: return keys[0][1]
    if t>=keys[-1][0]: return keys[-1][1]
    for (ta,va),(tb,vb) in zip(keys,keys[1:]):
        if ta<=t<=tb:
            u=(t-ta)/(tb-ta); u=u*u*(3-2*u) # smoothstep
            return interpolate(va,vb,u)
def path_xy(keys,t):
    return (keyframes_value([(k[0],k[1]) for k in keys],t),
            keyframes_value([(k[0],k[2]) for k in keys],t))
def camera_zoom(t,duration,start=1.0,end=1.12):
    u=max(0,min(1,t/max(duration,1e-5))); return start+(end-start)*u
def camera_pan(t,duration,from_xy,to_xy):
    u=max(0,min(1,t/max(duration,1e-5))); u=u*u*(3-2*u)
    return (from_xy[0]+(to_xy[0]-from_xy[0])*u,from_xy[1]+(to_xy[1]-from_xy[1])*u)
