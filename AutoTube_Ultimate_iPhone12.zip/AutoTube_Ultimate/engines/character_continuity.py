"""Character identity and visual-continuity helpers for scene prompting.

These utilities preserve written design traits and reference paths. Actual image
identity consistency depends on the selected provider supporting reference images.
"""
from __future__ import annotations
from pathlib import Path
from typing import Iterable, Mapping
import json, shutil

PROFILE_FILE = "character_profiles.json"

def create_profile(name: str, description: str, *, style: str = "cinematic 2.5D documentary", traits: Iterable[str] = (), reference: str | None = None) -> dict:
    if not name or not name.strip(): raise ValueError("Character name is required")
    if not description or not description.strip(): raise ValueError("Character description is required")
    trait_list = [str(t).strip() for t in traits if str(t).strip()]
    return {"name": name.strip(), "description": description.strip(), "style": style,
            "traits": trait_list, "reference": reference,
            "identity_lock": f"Keep {name.strip()} visually identical: {description.strip()}" +
                ("; " + "; ".join(trait_list) if trait_list else "")}

def save_profiles(project_dir, profiles: Mapping[str, dict]) -> str:
    root=Path(project_dir); root.mkdir(parents=True,exist_ok=True)
    path=root/PROFILE_FILE
    path.write_text(json.dumps(dict(profiles),indent=2,ensure_ascii=False),encoding="utf8")
    return str(path)

def load_profiles(project_dir) -> dict:
    path=Path(project_dir)/PROFILE_FILE
    if not path.exists(): return {}
    data=json.loads(path.read_text(encoding="utf8"))
    if not isinstance(data,dict): raise ValueError("Character profile file must contain an object")
    return data

def attach_reference(profile: dict, image_path, project_dir, character_id: str) -> dict:
    """Copy a reference image into project assets and return updated profile."""
    source=Path(image_path)
    if not source.is_file(): raise FileNotFoundError(source)
    folder=Path(project_dir)/"assets"/"character_references"; folder.mkdir(parents=True,exist_ok=True)
    suffix=source.suffix.lower() or ".png"
    target=folder/(f"{character_id}{suffix}")
    shutil.copy2(source,target)
    updated=dict(profile); updated["reference"]=str(target); return updated

def scene_prompt(base_prompt: str, characters: Iterable[str], profiles: Mapping[str,dict], *, continuity_notes: str = "") -> str:
    """Add stable character descriptions and shot-to-shot continuity directives."""
    blocks=[]
    for key in characters:
        p=profiles.get(key)
        if not p: raise KeyError(f"Unknown character profile: {key}")
        blocks.append(f"CHARACTER {p.get('name',key)} — {p.get('identity_lock') or p.get('description','')}. "
                     f"Reference image: {p.get('reference') or 'none supplied'}.")
    text=base_prompt.strip()
    if blocks: text += "\n\nIDENTITY CONTINUITY (do not redesign characters):\n"+"\n".join(blocks)
    if continuity_notes.strip(): text += "\n\nSHOT CONTINUITY: "+continuity_notes.strip()
    text += "\nMaintain the same anatomy, markings, colors, proportions, and recognizable silhouette across shots."
    return text

def validate_scene_characters(scenes: Iterable[dict], profiles: Mapping[str,dict]) -> list[dict]:
    """Return scene-indexed warnings for missing/unknown character references."""
    warnings=[]
    for index,scene in enumerate(scenes,1):
        names=scene.get("characters",[])
        if isinstance(names,str): names=[names]
        for name in names:
            if name not in profiles: warnings.append({"scene":scene.get("scene_id",index),"character":name,"issue":"missing_profile"})
    return warnings
