"""Media quality inspection utilities for AutoTube exports."""
from __future__ import annotations
import json
import re
import subprocess
from pathlib import Path
from typing import Any


def _run(command: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(command, capture_output=True, text=True, check=False)


def inspect_mp4(path: str | Path) -> dict[str, Any]:
    """Probe an MP4 and return stream metadata (backward-compatible API)."""
    p = _run(["ffprobe", "-v", "error", "-show_entries",
              "format=duration,size:stream=codec_type,codec_name,width,height,sample_rate,channels",
              "-of", "json", str(path)])
    if p.returncode:
        return {"ok": False, "error": p.stderr.strip() or "ffprobe failed"}
    try:
        data = json.loads(p.stdout)
        return {"ok": True, "duration": float(data["format"]["duration"]),
                "size_bytes": int(data["format"].get("size", 0)),
                "streams": data.get("streams", [])}
    except (ValueError, KeyError, TypeError) as exc:
        return {"ok": False, "error": f"Invalid ffprobe response: {exc}"}


def _subtitle_end(path: Path) -> float | None:
    """Read the last SRT timestamp; tolerate blank/malformed cue blocks."""
    if not path.exists():
        return None
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    stamps = re.findall(r"\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->\s*(\d{2}:\d{2}:\d{2}[,.]\d{3})", text)
    if not stamps:
        return None
    h, m, s = stamps[-1].replace(",", ".").split(":")
    return int(h) * 3600 + int(m) * 60 + float(s)


def inspect_video(path: str | Path, *, subtitles: str | Path | None = None,
                  expected_duration: float | None = None, black_threshold: float = 0.98,
                  black_min_duration: float = 1.0, silence_min_duration: float = 8.0,
                  run_content_checks: bool = True) -> dict[str, Any]:
    """Run export QC: streams, duration, black frames, silence, and subtitle bounds.

    Returns a JSON-serializable report. Content detections are warnings by default;
    missing/corrupt video or missing required streams are errors.
    """
    video = Path(path)
    report: dict[str, Any] = {"file": str(video.resolve()), "status": "passed",
                              "errors": [], "warnings": [], "checks": {}}
    if not video.is_file():
        report["status"] = "failed"
        report["errors"].append(f"Video file does not exist: {video}")
        return report
    probe = inspect_mp4(video)
    report["checks"]["probe"] = probe
    if not probe.get("ok"):
        report["status"] = "failed"
        report["errors"].append(probe.get("error", "Unable to inspect video"))
        return report
    streams = probe["streams"]
    types = {s.get("codec_type") for s in streams}
    duration = probe["duration"]
    report["duration_seconds"] = duration
    report["size_bytes"] = probe["size_bytes"]
    report["checks"]["video_stream"] = "video" in types
    report["checks"]["audio_stream"] = "audio" in types
    if "video" not in types:
        report["errors"].append("No video stream found")
    if "audio" not in types:
        report["warnings"].append("No audio stream found")
    if expected_duration is not None:
        delta = abs(duration - float(expected_duration))
        report["checks"]["expected_duration_delta_seconds"] = round(delta, 3)
        if delta > max(2.0, float(expected_duration) * 0.03):
            report["warnings"].append(f"Duration differs from expected by {delta:.2f}s")
    if subtitles:
        sub = Path(subtitles)
        if not sub.is_file():
            report["errors"].append(f"Subtitle file does not exist: {sub}")
        else:
            end = _subtitle_end(sub)
            report["checks"]["subtitle_last_end_seconds"] = end
            if end is None:
                report["warnings"].append("Subtitle file has no recognizable SRT cues")
            elif end > duration + 1.0:
                report["warnings"].append(f"Subtitles extend {end-duration:.2f}s beyond video")
    if run_content_checks:
        # FFmpeg blackdetect and silencedetect are analysis filters, not hard failures.
        black = _run(["ffmpeg", "-hide_banner", "-i", str(video), "-vf",
                      f"blackdetect=d={black_min_duration}:pix_th={black_threshold}",
                      "-an", "-f", "null", "-"])
        black_events = re.findall(r"black_start:([\d.]+) black_end:([\d.]+) black_duration:([\d.]+)", black.stderr)
        report["checks"]["black_segments"] = [
            {"start": float(a), "end": float(b), "duration": float(c)} for a,b,c in black_events]
        if black_events:
            report["warnings"].append(f"Detected {len(black_events)} black segment(s) >= {black_min_duration}s")
        if "audio" in types:
            silence = _run(["ffmpeg", "-hide_banner", "-i", str(video), "-af",
                           f"silencedetect=noise=-50dB:d={silence_min_duration}",
                           "-vn", "-f", "null", "-"])
            silences = re.findall(r"silence_start:([\d.]+).*?silence_end:([\d.]+).*?silence_duration:([\d.]+)", silence.stderr, re.S)
            report["checks"]["silence_segments"] = [
                {"start": float(a), "end": float(b), "duration": float(c)} for a,b,c in silences]
            if silences:
                report["warnings"].append(f"Detected {len(silences)} long audio silence(s)")
    report["status"] = "failed" if report["errors"] else ("warning" if report["warnings"] else "passed")
    report["summary"] = {"errors": len(report["errors"]), "warnings": len(report["warnings"]),
                         "checks": len(report["checks"])}
    return report


def write_qc_report(report: dict[str, Any], output: str | Path) -> str:
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, indent=2), encoding="utf-8")
    return str(target.resolve())
