"""Storyboard-to-animation bridge for asset-backed 2D scenes (AutoTube v0.6)."""
from __future__ import annotations
import json, shutil, subprocess
from pathlib import Path
from typing import Mapping, Sequence
from PIL import Image
from engines.rig_engine import Part
from engines.character_animation_renderer import render_character_scene
from engines.composition_engine import auto_compose


def _asset(assets: Mapping, key: str, label: str) -> Path:
    value = assets.get(key)
    if not value:
        raise ValueError(f"Scene requires {label} asset key {key!r}; add it to assets.")
    path = Path(value)
    if not path.is_file():
        raise FileNotFoundError(f"{label} asset does not exist: {path}")
    return path


def _apply_clip_fades(clip, duration, transition, fade_seconds=0.45):
    """Apply simple fade-through-black transitions to a rendered scene clip."""
    transition=str(transition or "cut").lower()
    if transition not in {"cut", "fade", "fade_black"}:
        raise ValueError(f"Unsupported transition {transition!r}; use cut or fade")
    if transition == "cut": return
    ffmpeg=shutil.which("ffmpeg")
    if not ffmpeg: raise RuntimeError("FFmpeg executable not found")
    d=min(float(fade_seconds),float(duration)/2)
    temp=Path(clip).with_name(Path(clip).stem+"_fade.mp4")
    vf=f"fade=t=in:st=0:d={d},fade=t=out:st={max(0,duration-d)}:d={d}"
    subprocess.run([ffmpeg,"-y","-i",str(clip),"-vf",vf,"-c:v","libx264","-preset","medium","-crf","18","-pix_fmt","yuv420p","-an",str(temp)],check=True,capture_output=True,text=True)
    temp.replace(clip)


def render_storyboard(storyboard: Sequence[dict], assets: Mapping, output_dir,
                      canvas_size=(1920, 1080), fps=30, keep_frames=False):
    """Render storyboard scenes to MP4 clips.

    Scene schema: {scene_id,start,end,background,character:{parts:[{image,pivot,offset,
    scale,rotation,z}],motion,start_xy,path,motion_options}}. `background` and each
    part `image` are keys in the supplied asset mapping, not raw paths.
    Returns a JSON-serializable manifest with clip paths and scene durations.
    """
    if not storyboard:
        raise ValueError("Storyboard must contain at least one scene")
    if fps <= 0: raise ValueError("fps must be positive")
    outdir=Path(output_dir); outdir.mkdir(parents=True,exist_ok=True)
    manifest=[]
    for index, scene in enumerate(storyboard, start=1):
        sid=scene.get("scene_id",index)
        try: duration=float(scene["duration"] if "duration" in scene else float(scene["end"])-float(scene["start"]))
        except (KeyError,TypeError,ValueError) as exc: raise ValueError(f"Scene {sid}: valid start/end or duration required") from exc
        if duration <= 0: raise ValueError(f"Scene {sid}: duration must be positive")
        bg=_asset(assets,scene.get("background"),f"background for scene {sid}")
        character=scene.get("character")
        if not isinstance(character,dict) or not character.get("parts"):
            raise ValueError(f"Scene {sid}: character.parts must contain rig part definitions")
        parts=[]
        for part_data in character["parts"]:
            if "image" not in part_data: raise ValueError(f"Scene {sid}: rig part missing image asset key")
            image=_asset(assets,part_data["image"],f"rig part in scene {sid}")
            parts.append(Part(image=str(image),pivot=tuple(part_data.get("pivot",(.5,.5))),
                offset=tuple(part_data.get("offset",(0,0))),scale=float(part_data.get("scale",1)),
                rotation=float(part_data.get("rotation",0)),z=int(part_data.get("z",0))))
        clip=outdir/f"scene_{index:03d}.mp4"
        render_character_scene(bg,parts,clip,duration,canvas_size=canvas_size,
            motion=character.get("motion","idle"),start_xy=tuple(character.get("start_xy",(.5,.72))),
            path=character.get("path"),fps=fps,motion_options=character.get("motion_options"),
            keep_frames=keep_frames, camera=scene.get("camera"))
        _apply_clip_fades(clip,duration,scene.get("transition","cut"),scene.get("transition_duration",0.45))
        manifest.append({"scene_id":sid,"clip":str(clip.resolve()),"duration":duration,
            "start":scene.get("start"),"end":scene.get("end"),"narration":scene.get("narration",""),"camera":scene.get("camera"),
            "transition":scene.get("transition","cut")})
    manifest_path=outdir/"animation_manifest.json"
    manifest_path.write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    return {"scenes":manifest,"manifest":str(manifest_path.resolve()),"count":len(manifest),
            "total_duration":sum(item["duration"] for item in manifest)}


def preview_story_scene(background, parts, time_seconds=0, canvas_size=(640,360), motion="idle",
                        start_xy=(.5,.72), path=None, motion_options=None):
    """Return a single RGBA preview frame without invoking FFmpeg."""
    from engines.character_animation_renderer import render_character_frames
    return next(render_character_frames(background,parts,max(float(time_seconds),1/12),
        canvas_size=canvas_size,motion=motion,start_xy=start_xy,path=path,fps=12,
        motion_options=motion_options))
