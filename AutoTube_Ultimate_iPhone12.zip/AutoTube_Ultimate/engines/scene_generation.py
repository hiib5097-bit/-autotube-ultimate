"""Scene asset orchestration; expects an image provider that returns real artwork."""
from pathlib import Path
from engines.image_engine import generate_scene_image
def create_scene_assets(storyboard, output_dir, provider, character_reference=None):
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True); result=[]
    for scene in storyboard:
        path=out/f"scene_{scene['scene_id']:03}.png"
        generate_scene_image(scene["visual_prompt"],path,character_reference,provider)
        if not path.exists(): raise RuntimeError(f"Image provider did not create {path}")
        result.append(str(path))
    return result
