from pathlib import Path
import shutil, json
from engines.character_sheet import character_prompt
def register_reference(image_path, project_dir):
    if not image_path: return None
    target=Path(project_dir)/("character_reference"+Path(image_path).suffix.lower())
    shutil.copy2(image_path,target); return str(target)
def save_character_profile(project_dir, name, description, reference=None, style="2D cartoon"):
    p=Path(project_dir); p.mkdir(parents=True,exist_ok=True)
    profile={"name":name,"description":description,"style":style,"reference":reference,
             "generation_prompt":character_prompt(description,style)}
    (p/"character_profile.json").write_text(json.dumps(profile,indent=2),encoding="utf8")
    return profile
