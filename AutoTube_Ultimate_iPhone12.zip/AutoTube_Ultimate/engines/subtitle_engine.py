from utils.timestamp_utils import srt_timestamp
def write_srt(segments, path):
    with open(path,"w",encoding="utf-8") as f:
        for i,s in enumerate(segments,1):
            f.write(f"{i}\n{srt_timestamp(s['start'])} --> {srt_timestamp(s['end'])}\n{s['text']}\n\n")
    return path
