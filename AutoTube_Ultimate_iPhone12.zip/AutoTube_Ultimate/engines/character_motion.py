"""Procedural character motion library for AutoTube's layered 2D puppet rigs.

Pose dictionaries use the part indices documented by a character rig. The default
convention is: 0 torso/head group, 1/2 arms, 3/4 legs, 5 mouth (optional).
All motions are deterministic and can be sampled at any time/FPS.
"""
from __future__ import annotations
import math
from typing import Dict, Callable

Pose = Dict[int, dict]


def idle(t: float, intensity: float = 1.0) -> Pose:
    """Subtle breathing and head sway; suitable for a standing character."""
    p = 2 * math.pi * t
    return {0: {"offset": (0.0, -2.5 * intensity * (0.5 + 0.5 * math.sin(p))),
                "rotation": 1.2 * intensity * math.sin(p * 0.5)}}


def walk(t: float, speed: float = 1.0, stride: float = 1.0) -> Pose:
    """Looping walk cycle with alternating arms/legs and body bounce."""
    phase = 2 * math.pi * max(0.0, speed) * t
    swing = math.sin(phase)
    return {
        0: {"offset": (0.0, -4.0 * stride * abs(swing)), "rotation": 2.0 * swing},
        1: {"rotation": 25.0 * stride * swing},
        2: {"rotation": -25.0 * stride * swing},
        3: {"rotation": -32.0 * stride * swing},
        4: {"rotation": 32.0 * stride * swing},
    }


def run(t: float, speed: float = 1.7, stride: float = 1.25) -> Pose:
    """Looping run cycle with stronger limb swings and airborne bounce."""
    phase = 2 * math.pi * max(0.0, speed) * t
    swing = math.sin(phase)
    bounce = abs(math.sin(phase * 2))
    return {
        0: {"offset": (0.0, -9.0 * stride * bounce), "rotation": 4.0 * swing},
        1: {"rotation": 48.0 * stride * swing},
        2: {"rotation": -48.0 * stride * swing},
        3: {"rotation": -55.0 * stride * swing},
        4: {"rotation": 55.0 * stride * swing},
    }


def talk(t: float, intensity: float = 1.0) -> Pose:
    """Head gestures and optional mouth-part scale pulse."""
    p = 2 * math.pi * t
    pose = {0: {"rotation": 2.0 * intensity * math.sin(p * 1.7),
                "offset": (0.0, -1.5 * intensity * (0.5 + 0.5 * math.sin(p * 2)))}}
    pose[5] = {"scale": 1.0 + 0.12 * intensity * (0.5 + 0.5 * math.sin(p * 4))}
    return pose


def wave(t: float, arm_index: int = 1, cycles: float = 2.0) -> Pose:
    """Raise and wave one arm; animation is normalized to a 0..1 duration."""
    u = max(0.0, min(1.0, t))
    raise_amount = min(1.0, u * 5.0)
    oscillation = math.sin(2 * math.pi * cycles * u) * (1.0 if u > .15 else u / .15)
    return {arm_index: {"rotation": -105.0 * raise_amount + 18.0 * oscillation}}

MOTIONS: Dict[str, Callable[..., Pose]] = {"idle": idle, "walk": walk, "run": run, "talk": talk, "wave": wave}

def get_pose(motion: str, t: float, **kwargs) -> Pose:
    """Resolve a named motion, raising a useful error for unknown motion names."""
    try:
        fn = MOTIONS[motion.lower()]
    except KeyError as exc:
        raise ValueError(f"Unknown character motion '{motion}'. Choose: {', '.join(MOTIONS)}") from exc
    return fn(t, **kwargs)
