"""FFmpeg-based final assembly for AutoTube."""
from pathlib import Path
import shutil
import subprocess


def _escape_subtitle_filter(path: Path) -> str:
    """Escape a filesystem path for FFmpeg's subtitles filter syntax."""
    value = str(path.resolve()).replace('\\', '/').replace(':', r'\\:')
    value = value.replace("'", r"\\'").replace(',', r"\\,")
    return value


def render(video_scenes, audio, output, srt=None, vertical=False):
    """Concatenate scene clips, mux narration, optionally burn SRT captions.

    Inputs are paths. Raises clear errors if FFmpeg or any media input is absent.
    """
    output = Path(output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    scenes = [Path(p).resolve() for p in video_scenes]
    audio = Path(audio).resolve()
    if not scenes:
        raise ValueError("Cannot render: no scene clips were supplied")
    missing = [str(p) for p in [*scenes, audio] if not p.is_file()]
    if missing:
        raise FileNotFoundError("Missing media input(s): " + ", ".join(missing))
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("FFmpeg executable not found. Install FFmpeg and add it to PATH.")

    concat = output.with_suffix(".concat.txt")
    # FFmpeg concat demuxer uses single-quoted paths; escape embedded apostrophes.
    concat.write_text("\n".join("file '" + str(p).replace("'", "'\\''") + "'" for p in scenes), encoding="utf-8")
    cmd = [ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(concat), "-i", str(audio)]
    if srt:
        subtitle_path = Path(srt).resolve()
        if not subtitle_path.is_file():
            raise FileNotFoundError(f"Subtitle file not found: {subtitle_path}")
        cmd += ["-vf", "subtitles='" + _escape_subtitle_filter(subtitle_path) + "'"]
    cmd += ["-map", "0:v:0", "-map", "1:a:0", "-r", "30", "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-shortest", str(output)]
    subprocess.run(cmd, check=True, capture_output=True, text=True)
    if not output.exists() or output.stat().st_size == 0:
        raise RuntimeError("FFmpeg completed without producing a valid output file")
    return output
