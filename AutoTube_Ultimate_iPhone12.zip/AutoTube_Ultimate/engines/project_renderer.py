"""One-call storyboard-to-final-video project renderer (AutoTube v0.7)."""
from __future__ import annotations
import json
from pathlib import Path
from engines.scene_animation_engine import render_storyboard
from engines.rendering_engine import render as assemble_video
from engines.quality_control import inspect_video, write_qc_report


def render_project(storyboard, assets, narration_audio, output, project_dir=None,
                  subtitles=None, canvas_size=(1920,1080), fps=30, vertical=False,
                  keep_frames=False):
    """Render storyboard clips, concatenate them, and mux narration/captions.

    `storyboard` uses the v0.6 scene schema and `assets` maps asset keys to files.
    The output is a final MP4. Returns paths, durations, and a JSON report.
    """
    output=Path(output).resolve()
    root=Path(project_dir).resolve() if project_dir else output.parent/(output.stem+"_project")
    root.mkdir(parents=True,exist_ok=True)
    if not Path(narration_audio).is_file():
        raise FileNotFoundError(f"Narration audio not found: {narration_audio}")
    if subtitles and not Path(subtitles).is_file():
        raise FileNotFoundError(f"Subtitle file not found: {subtitles}")
    animation=render_storyboard(storyboard,assets,root/"clips",canvas_size=canvas_size,
                                fps=fps,keep_frames=keep_frames)
    clip_paths=[scene["clip"] for scene in animation["scenes"]]
    final=assemble_video(clip_paths,narration_audio,output,srt=subtitles,vertical=vertical)
    report={"status":"complete","output":str(Path(final).resolve()),
            "scene_count":animation["count"],"scene_duration_seconds":animation["total_duration"],
            "narration_audio":str(Path(narration_audio).resolve()),
            "subtitles":str(Path(subtitles).resolve()) if subtitles else None,
            "animation_manifest":animation["manifest"],"file_size_bytes":Path(final).stat().st_size}
    qc=inspect_video(final,subtitles=subtitles,expected_duration=animation["total_duration"],run_content_checks=True)
    report["quality_control"]=qc
    report_path=root/"render_report.json"
    report_path.write_text(json.dumps(report,indent=2),encoding="utf-8")
    report["report"] = str(report_path)
    report["qc_report"] = write_qc_report(qc,root/"quality_control.json")
    return report
