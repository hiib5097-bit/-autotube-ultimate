from providers.image_provider import ImageProvider
def generate_scene_image(prompt, output_path, reference=None, provider=None):
    return (provider or ImageProvider()).generate(prompt, output_path, reference)
