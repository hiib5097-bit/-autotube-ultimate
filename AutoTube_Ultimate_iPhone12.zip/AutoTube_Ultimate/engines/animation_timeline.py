"""Reusable animation timeline with interpolated property tracks and easing.

Tracks are JSON-friendly: {"property": "x", "keyframes": [{"time": 0, "value": 0}, ...]}.
Values may be numbers or numeric tuples/lists. This module does not require FFmpeg.
"""
from dataclasses import dataclass
from typing import Any, Iterable


def _lerp(a: Any, b: Any, u: float) -> Any:
    if isinstance(a, (tuple, list)) and isinstance(b, (tuple, list)):
        if len(a) != len(b):
            raise ValueError("Keyframe vector values must have equal lengths")
        result = [_lerp(x, y, u) for x, y in zip(a, b)]
        return tuple(result) if isinstance(a, tuple) else result
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return a + (b - a) * u
    raise TypeError(f"Unsupported keyframe values: {type(a).__name__}, {type(b).__name__}")


def ease(progress: float, mode: str = "smooth") -> float:
    u = max(0.0, min(1.0, float(progress)))
    if mode == "linear": return u
    if mode == "smooth": return u * u * (3 - 2 * u)
    if mode == "ease_in": return u * u
    if mode == "ease_out": return 1 - (1 - u) ** 2
    raise ValueError(f"Unknown easing mode: {mode}")


@dataclass(frozen=True)
class Keyframe:
    time: float
    value: Any
    easing: str = "smooth"


class Track:
    def __init__(self, property_name: str, keyframes: Iterable[Keyframe | dict]):
        self.property = property_name
        self.keyframes = sorted((k if isinstance(k, Keyframe) else Keyframe(**k) for k in keyframes), key=lambda k:k.time)
        if not self.property: raise ValueError("Track property cannot be empty")
        if not self.keyframes: raise ValueError("Track needs at least one keyframe")
        if any(k.time < 0 for k in self.keyframes): raise ValueError("Keyframe time cannot be negative")
        if len({k.time for k in self.keyframes}) != len(self.keyframes): raise ValueError("Keyframe times must be unique")

    def value_at(self, time: float):
        t=float(time)
        if t <= self.keyframes[0].time: return self.keyframes[0].value
        if t >= self.keyframes[-1].time: return self.keyframes[-1].value
        for left, right in zip(self.keyframes, self.keyframes[1:]):
            if left.time <= t <= right.time:
                u=ease((t-left.time)/(right.time-left.time), right.easing)
                return _lerp(left.value, right.value, u)
        return self.keyframes[-1].value


class AnimationTimeline:
    def __init__(self, duration: float, tracks: Iterable[Track] = ()):
        if duration <= 0: raise ValueError("Timeline duration must be positive")
        self.duration=float(duration); self.tracks=list(tracks)

    def add_track(self, track: Track): self.tracks.append(track); return self

    def evaluate(self, time: float) -> dict:
        t=max(0.0,min(self.duration,float(time)))
        return {track.property:track.value_at(t) for track in self.tracks}

    def sample(self, fps: int = 30):
        if fps <= 0: raise ValueError("FPS must be positive")
        count=max(1,int(self.duration*fps))
        return [(i/fps,self.evaluate(i/fps)) for i in range(count)]
