import re
def sentence_chunks(transcript, target_seconds=6):
    # Group transcript segments into readable scene beats (heuristic; timings remain anchored to audio).
    segs=transcript["segments"]; scenes=[]; current=[]
    for s in segs:
        current.append(s)
        if s["end"]-current[0]["start"] >= target_seconds or re.search(r'[.!?]$',s["text"]):
            scenes.append(current); current=[]
    if current: scenes.append(current)
    return [{"scene_id":i+1,"start":c[0]["start"],"end":c[-1]["end"],
             "narration":" ".join(x["text"] for x in c)} for i,c in enumerate(scenes)]
