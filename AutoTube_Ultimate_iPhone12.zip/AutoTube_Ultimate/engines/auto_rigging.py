"""Semi-automatic character image preparation for AutoTube puppet rigs.

Background removal is optional (rembg extra). Body-part separation is driven by
editable normalized regions: this avoids pretending a generic segmenter can infer
anatomically correct joints from every character image.
"""
from __future__ import annotations
from pathlib import Path
from typing import Mapping, Sequence
import json
from PIL import Image

PARTS = ("torso", "head", "left_arm", "right_arm", "left_leg", "right_leg", "mouth")

class RigPreparationError(ValueError): pass

def remove_background(source: str | Path, output: str | Path) -> Path:
    """Remove background using optional rembg. Install with `pip install rembg`."""
    try:
        from rembg import remove
    except ImportError as exc:
        raise RuntimeError("Background removal needs optional dependency: pip install rembg") from exc
    src, dst = Path(source), Path(output)
    dst.parent.mkdir(parents=True, exist_ok=True)
    result = remove(src.read_bytes())
    dst.write_bytes(result)
    return dst


def extract_parts(source: str | Path, output_dir: str | Path,
                  regions: Mapping[str, Sequence[float]], *, padding: int = 8,
                  min_alpha: int = 1) -> dict:
    """Crop transparent part PNGs from a character sheet using normalized boxes.

    regions values are (x0,y0,x1,y1) in 0..1. Boxes should overlap at joints.
    Input should already have transparent background for clean puppet layers.
    """
    src, out = Path(source), Path(output_dir)
    if padding < 0: raise RigPreparationError("padding must be >= 0")
    im = Image.open(src).convert("RGBA"); w,h=im.size
    out.mkdir(parents=True, exist_ok=True)
    manifest={"source":str(src),"canvas":[w,h],"parts":{},"notes":"Review pivots and joint overlaps before animation."}
    for name, box in regions.items():
        if name not in PARTS: raise RigPreparationError(f"Unknown part: {name}")
        if len(box)!=4 or not all(0<=float(v)<=1 for v in box): raise RigPreparationError(f"Invalid normalized box for {name}")
        x0,y0,x1,y1=map(float,box)
        if x1<=x0 or y1<=y0: raise RigPreparationError(f"Empty box for {name}")
        left=max(0,int(x0*w)-padding); top=max(0,int(y0*h)-padding)
        right=min(w,int(x1*w)+padding); bottom=min(h,int(y1*h)+padding)
        crop=im.crop((left,top,right,bottom))
        if crop.getchannel("A").getbbox() is None: raise RigPreparationError(f"Part {name} has no visible pixels")
        path=out/f"{name}.png"; crop.save(path)
        manifest["parts"][name]={"file":path.name,"crop":[left,top,right,bottom],"pivot":[0.5,0.5],"offset":[0,0],"z":len(manifest["parts"])}
    (out/"rig_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    return manifest


def validate_rig_folder(folder: str | Path) -> list[str]:
    """Return actionable validation errors; empty list means required files exist."""
    p=Path(folder); errors=[]
    required=PARTS[:6]
    for name in required:
        f=p/f"{name}.png"
        if not f.is_file(): errors.append(f"Missing {f.name}")
        else:
            try:
                with Image.open(f) as im:
                    if im.mode not in ("RGBA","LA") and "transparency" not in im.info: errors.append(f"{f.name} lacks transparency")
                    if im.width<2 or im.height<2: errors.append(f"{f.name} is too small")
            except Exception: errors.append(f"Unreadable image: {f.name}")
    if not (p/"rig_manifest.json").is_file(): errors.append("Missing rig_manifest.json")
    return errors
