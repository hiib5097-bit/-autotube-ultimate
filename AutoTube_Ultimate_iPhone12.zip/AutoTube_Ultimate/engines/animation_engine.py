"""Real motion fallback: animates a still scene with scale/pan keyframes."""
import subprocess, math
from utils.media_utils import require_ffmpeg
def animate_image(image_path, output_path, duration, width, height, motion="push"):
    require_ffmpeg()
    # Ken Burns motion is genuine frame-by-frame camera movement, not a static slideshow.
    zoom="min(1.12,1+0.10*t/"+str(max(duration,0.1))+")" if motion=="push" else "1.08"
    x="(iw-iw/zoom)/2"; y="(ih-ih/zoom)/2"
    vf=f"scale={width*2}:{height*2}:force_original_aspect_ratio=increase,crop={width*2}:{height*2},zoompan=z='{zoom}':x='{x}':y='{y}':d=1:s={width}x{height}:fps=30,format=yuv420p"
    subprocess.run(["ffmpeg","-y","-loop","1","-i",str(image_path),"-t",str(duration),"-vf",vf,"-r","30","-an",str(output_path)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    return output_path
