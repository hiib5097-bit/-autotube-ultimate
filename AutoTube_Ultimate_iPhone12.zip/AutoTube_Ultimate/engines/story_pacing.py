"""Narration-aware scene planner for AutoTube.

Turns a narration script into reasonably paced, editable storyboard rows before
artwork/rig assets are attached. This is deterministic (no API key required).
"""
from __future__ import annotations
import re
from typing import Any

DEFAULT_WPM = 145.0


def estimate_speech_duration(text: str, words_per_minute: float = DEFAULT_WPM,
                             pause_seconds: float = 0.18) -> float:
    """Estimate spoken duration including punctuation pauses."""
    if words_per_minute <= 0:
        raise ValueError("words_per_minute must be positive")
    words = re.findall(r"\b[\w’'-]+\b", text, flags=re.UNICODE)
    pauses = len(re.findall(r"[,;:!?…]", text)) * max(0.0, pause_seconds)
    return max(0.0, len(words) * 60.0 / words_per_minute + pauses)


def split_narration(text: str, *, max_words: int = 35) -> list[str]:
    """Split script into scene-sized chunks, preferring paragraph/sentence breaks."""
    if max_words < 5:
        raise ValueError("max_words must be at least 5")
    text = text.strip()
    if not text:
        return []
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    sentences: list[str] = []
    for paragraph in paragraphs:
        pieces = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9‘\"'])", paragraph)
        sentences.extend(x.strip() for x in pieces if x.strip())
    chunks: list[str] = []
    current: list[str] = []
    count = 0
    for sentence in sentences:
        n = len(re.findall(r"\b[\w’'-]+\b", sentence))
        if current and count + n > max_words:
            chunks.append(" ".join(current)); current=[]; count=0
        # Keep long sentences intact rather than cutting grammar mid-sentence.
        current.append(sentence); count += n
    if current:
        chunks.append(" ".join(current))
    return chunks


def plan_storyboard(narration: str, *, words_per_minute: float = DEFAULT_WPM,
                    max_words_per_scene: int = 35, visual_style: str = "Cinematic documentary",
                    minimum_scene_seconds: float = 2.5) -> list[dict[str, Any]]:
    """Create scene rows with stable IDs, timings, and image prompts."""
    chunks = split_narration(narration, max_words=max_words_per_scene)
    scenes=[]; cursor=0.0
    for i, chunk in enumerate(chunks, 1):
        duration=max(minimum_scene_seconds, estimate_speech_duration(chunk,words_per_minute))
        end=cursor+duration
        scenes.append({"scene_id":i,"start":round(cursor,3),"end":round(end,3),
            "duration":round(duration,3),"narration":chunk,
            "visual_prompt":f"{visual_style}, 16:9 cinematic composition. Show: {chunk}",
            "transition":"fade" if i>1 else "cut"})
        cursor=end
    return scenes
