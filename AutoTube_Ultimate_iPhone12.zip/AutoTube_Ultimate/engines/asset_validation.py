from pathlib import Path
from PIL import Image
def validate_transparent_parts(folder):
    report=[]
    for p in Path(folder).glob("*.png"):
        try:
            im=Image.open(p).convert("RGBA")
            report.append({"file":p.name,"size":im.size,"alpha":im.getchannel("A").getextrema(),"ok":True})
        except Exception as e: report.append({"file":p.name,"ok":False,"error":str(e)})
    return report
