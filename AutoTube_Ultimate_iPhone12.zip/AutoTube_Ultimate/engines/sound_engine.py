"""Optional ambience/music mixing. Voiceover stays foreground."""
import subprocess
def mix_audio(voice, output, music=None, sfx=None):
    if not music and not sfx:
        subprocess.run(["ffmpeg","-y","-i",str(voice),"-af","loudnorm","-c:a","aac","-b:a","192k",str(output)],check=True)
        return output
    inputs=["-i",str(voice)]; filters=["[0:a]volume=1.0[vo]"]; labels=["[vo]"]; idx=1
    if music:
        inputs+=["-i",str(music)]; filters += [f"[{idx}:a]volume=0.16[m]"]; labels.append("[m]"); idx+=1
    if sfx:
        inputs+=["-i",str(sfx)]; filters += [f"[{idx}:a]volume=0.25[s]"]; labels.append("[s]")
    filters += [f"{''.join(labels)}amix=inputs={len(labels)}:duration=first:dropout_transition=2,loudnorm[out]"]
    subprocess.run(["ffmpeg","-y",*inputs,"-filter_complex",";".join(filters),"-map","[out]","-c:a","aac",str(output)],check=True)
    return output
