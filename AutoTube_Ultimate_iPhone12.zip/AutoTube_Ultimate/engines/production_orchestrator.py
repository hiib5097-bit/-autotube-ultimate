"""Reusable pipeline coordinator (providers injected by caller)."""
from pathlib import Path
import json
from engines.audio_engine import inspect_audio
from engines.transcription_engine import transcribe
from engines.story_engine import sentence_chunks
from engines.storyboard_engine import make_storyboard
from engines.subtitle_engine import write_srt
def prepare_project(audio_path, project_dir, target_scene_seconds=6):
    p=Path(project_dir); p.mkdir(parents=True,exist_ok=True)
    audio=inspect_audio(audio_path); transcript=transcribe(audio_path)
    scenes=make_storyboard(sentence_chunks(transcript,target_scene_seconds))
    (p/"audio_info.json").write_text(json.dumps(audio,indent=2))
    (p/"transcript.json").write_text(json.dumps(transcript,indent=2))
    (p/"storyboard.json").write_text(json.dumps(scenes,indent=2))
    write_srt(transcript["segments"],p/"captions.srt")
    return {"project":str(p),"audio":audio,"transcript":transcript,"scenes":scenes,"srt":str(p/"captions.srt")}
