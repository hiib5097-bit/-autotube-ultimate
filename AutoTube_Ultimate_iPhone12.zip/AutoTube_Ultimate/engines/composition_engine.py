"""Automatic scene composition and documentary camera presets (AutoTube v0.9)."""
from __future__ import annotations

CAMERA_PRESETS = {
    "static": (1.00, 1.00, (0.0, 0.0), (0.0, 0.0)),
    "slow_push": (1.00, 1.14, (0.0, 0.0), (0.0, 0.0)),
    "slow_pull": (1.14, 1.00, (0.0, 0.0), (0.0, 0.0)),
    "drift_left": (1.08, 1.16, (0.12, 0.0), (-0.12, 0.0)),
    "drift_right": (1.08, 1.16, (-0.12, 0.0), (0.12, 0.0)),
    "dramatic": (1.02, 1.28, (0.0, 0.02), (0.0, -0.04)),
}


def camera_preset(name: str, subject_xy=(0.5, 0.72)) -> dict:
    """Return renderer-ready camera parameters for a named preset."""
    key = str(name or "static").lower().replace("-", "_")
    if key not in CAMERA_PRESETS:
        raise ValueError(f"Unknown camera preset {name!r}; choose {', '.join(CAMERA_PRESETS)}")
    z0, z1, p0, p1 = CAMERA_PRESETS[key]
    # Bias the framing gently toward the subject, without leaving the canvas.
    sx, sy = map(float, subject_xy)
    if not (0 <= sx <= 1 and 0 <= sy <= 1):
        raise ValueError("subject_xy coordinates must be normalized between 0 and 1")
    bias_x = max(-0.18, min(0.18, (sx - 0.5) * 0.35))
    bias_y = max(-0.12, min(0.12, (sy - 0.5) * 0.25))
    return {"start_zoom": z0, "end_zoom": z1,
            "start_pan": (p0[0] + bias_x, p0[1] + bias_y),
            "end_pan": (p1[0] + bias_x, p1[1] + bias_y), "preset": key}


def auto_compose(scene: dict) -> dict:
    """Resolve automatic placement/camera fields without mutating input scene."""
    result = dict(scene)
    character = dict(result.get("character") or {})
    position = character.get("start_xy", (0.5, 0.72))
    # Documentary default: lower third, centered; honor explicit placement.
    if position == "auto" or position is None:
        position = (0.5, 0.72)
    character["start_xy"] = tuple(position)
    result["character"] = character
    cam = result.get("camera")
    if cam == "auto" or isinstance(cam, str):
        preset = result.get("camera_style", "slow_push") if cam == "auto" else cam
        result["camera"] = camera_preset(preset, character["start_xy"])
    elif cam is None and result.get("camera_style"):
        result["camera"] = camera_preset(result["camera_style"], character["start_xy"])
    return result
