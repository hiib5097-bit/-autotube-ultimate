"""Simple 2D puppet rig using transparent PNG layers and timed keyframes.
Each character layer is a transparent PNG (head/body/arm/leg); pivots are specified in normalized coordinates.
"""
from dataclasses import dataclass
from PIL import Image
import math, subprocess
from pathlib import Path
from engines.character_motion import get_pose

@dataclass
class Part:
    image: str
    pivot: tuple=(0.5,0.5)
    offset: tuple=(0,0)
    scale: float=1.0
    rotation: float=0.0
    z: int=0

def _rotate_part(part, angle, scale=1.0):
    im=Image.open(part.image).convert("RGBA")
    if scale*part.scale != 1: im=im.resize((max(1,int(im.width*scale*part.scale)),max(1,int(im.height*scale*part.scale))))
    return im.rotate(angle+part.rotation,resample=Image.Resampling.BICUBIC,expand=True)

def render_rig_frame(parts, canvas_size, root_xy, pose=None, background=None):
    """Render one frame. pose maps part index -> {rotation, offset:[x,y], scale}."""
    W,H=canvas_size
    canvas=Image.new("RGBA",(W,H),(0,0,0,0))
    if background:
        bg=Image.open(background).convert("RGBA").resize((W,H)); canvas.alpha_composite(bg)
    for idx,p in enumerate(sorted(parts,key=lambda p:p.z)):
        q=(pose or {}).get(idx,{})
        x=root_xy[0]+p.offset[0]+q.get("offset",(0,0))[0]
        y=root_xy[1]+p.offset[1]+q.get("offset",(0,0))[1]
        angle=q.get("rotation",0)
        scale=q.get("scale",1)
        im=_rotate_part(p,angle,scale)
        # pivot approximation: center image at joint anchor
        px=int(x-im.width*p.pivot[0]); py=int(y-im.height*p.pivot[1])
        canvas.alpha_composite(im,(px,py))
    return canvas

def pose_walk(t, speed=1.0):
    """Deterministic walk cycle: alternating limbs and subtle body bob."""
    phase=2*math.pi*t*speed
    return {1:{"rotation":22*math.sin(phase)},2:{"rotation":-22*math.sin(phase)},
            3:{"rotation":-28*math.sin(phase)},4:{"rotation":28*math.sin(phase)},
            0:{"offset":(0,-4*abs(math.sin(phase)))}}

def pose_idle(t):
    return {0:{"rotation":2*math.sin(2*math.pi*t*.8)}}

def pose_talk(t):
    return {0:{"rotation":1.5*math.sin(2*math.pi*t*2)},5:{"scale":1+0.10*(0.5+0.5*math.sin(2*math.pi*t*4))}}

def render_rig_video(parts, output, duration, canvas_size=(1080,1920), root_xy=None, motion="idle", background=None, fps=30):
    W,H=canvas_size; root_xy=root_xy or (W//2,H//2)
    output=Path(output); output.parent.mkdir(parents=True,exist_ok=True)
    tmp=output.parent/(output.stem+"_frames"); tmp.mkdir(exist_ok=True)
    count=max(1,int(duration*fps))
    for i in range(count):
        t=i/fps
        pose=get_pose(motion, t)
        frame=render_rig_frame(parts,(W,H),root_xy,pose,background)
        frame.save(tmp/f"frame_{i:06d}.png")
    subprocess.run(["ffmpeg","-y","-framerate",str(fps),"-i",str(tmp/"frame_%06d.png"),"-t",str(duration),"-c:v","libx264","-pix_fmt","yuv420p",str(output)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    return output
