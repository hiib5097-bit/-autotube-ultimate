from config import WHISPER_MODEL
def transcribe(path, model_name=None):
    try:
        from faster_whisper import WhisperModel
    except ImportError as e: raise RuntimeError("Install faster-whisper from requirements.txt") from e
    model=WhisperModel(model_name or WHISPER_MODEL, device="cpu", compute_type="int8")
    segments, info=model.transcribe(str(path), word_timestamps=True, vad_filter=True)
    rows=[]
    for s in segments:
        rows.append({"start":float(s.start),"end":float(s.end),"text":s.text.strip(),
                     "words":[{"start":w.start,"end":w.end,"word":w.word} for w in (s.words or [])]})
    return {"language":info.language,"language_probability":info.language_probability,"segments":rows}
