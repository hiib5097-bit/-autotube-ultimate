def make_storyboard(scenes):
    for s in scenes:
        s["visual_prompt"] = ("2D cartoon storytelling frame; clear silhouettes, crisp outlines, "
            "expressive characters, cinematic composition. Visualize: "+s["narration"])
        s["motion"]={"camera":"slow push-in","subject":"subtle idle movement","transition":"cut"}
    return scenes
