"""Frame-based character animation and scene integration renderer.

Renders transparent PNG puppet parts into a scene frame, samples procedural poses,
optionally moves the character along a normalized path, and encodes an MP4 with FFmpeg.
"""
from __future__ import annotations
import math, shutil, subprocess
from pathlib import Path
from PIL import Image
from engines.character_motion import get_pose
from engines.rig_engine import Part, render_rig_frame


def _path_position(path, u):
    """Piecewise-linear path; points are normalized (0..1) canvas coordinates."""
    if not path:
        return None
    if len(path) == 1:
        return path[0]
    u = max(0.0, min(1.0, u)) * (len(path)-1)
    i = min(int(u), len(path)-2); f = u-i
    a,b=path[i],path[i+1]
    return (a[0]+(b[0]-a[0])*f, a[1]+(b[1]-a[1])*f)


def _apply_camera(scene, camera, progress):
    """Apply smooth Ken-Burns zoom/pan; pan values are normalized offsets."""
    if not camera: return scene
    W,H=scene.size
    z0=float(camera.get("start_zoom",1.0)); z1=float(camera.get("end_zoom",1.0))
    zoom=z0+(z1-z0)*progress
    if zoom <= 0: raise ValueError("camera zoom must be positive")
    px0,py0=camera.get("start_pan",(0.0,0.0)); px1,py1=camera.get("end_pan",(0.0,0.0))
    px=float(px0)+(float(px1)-float(px0))*progress
    py=float(py0)+(float(py1)-float(py0))*progress
    nw=max(W,int(round(W*zoom))); nh=max(H,int(round(H*zoom)))
    enlarged=scene.resize((nw,nh),Image.Resampling.LANCZOS)
    # Pan is measured in normalized fractions of the extra image area.
    extra_x=nw-W; extra_y=nh-H
    left=max(0,min(extra_x,int(extra_x*(0.5+px))))
    top=max(0,min(extra_y,int(extra_y*(0.5+py))))
    return enlarged.crop((left,top,left+W,top+H))


def render_character_scene(background, parts, output, duration, canvas_size=(1920,1080),
                           motion="idle", start_xy=(0.5,0.72), path=None, fps=30,
                           motion_options=None, keep_frames=False, camera=None):
    """Render a moving/animated character over a background into MP4.

    `parts` is a list of engines.rig_engine.Part instances. `path` is a list of
    normalized (x,y) positions. Background can be a file path or PIL image.
    Output is H.264 MP4. Temporary frames are removed unless keep_frames=True.
    """
    if duration <= 0 or fps <= 0: raise ValueError("duration and fps must be positive")
    if not parts: raise ValueError("At least one character rig part is required")
    ffmpeg=shutil.which("ffmpeg")
    if not ffmpeg: raise RuntimeError("FFmpeg executable not found")
    W,H=map(int,canvas_size); output=Path(output); output.parent.mkdir(parents=True,exist_ok=True)
    frames=output.parent/(output.stem+"_frames"); frames.mkdir(parents=True,exist_ok=True)
    bg=Image.open(background).convert("RGBA") if not isinstance(background,Image.Image) else background.convert("RGBA")
    bg=bg.resize((W,H),Image.Resampling.LANCZOS)
    count=max(1,math.ceil(duration*fps)); opts=motion_options or {}
    try:
        for i in range(count):
            t=i/fps; u=min(1.0,t/duration)
            pos=_path_position(path,u) if path else start_xy
            root=(int(pos[0]*W),int(pos[1]*H))
            frame=render_rig_frame(parts,(W,H),root,get_pose(motion,t,**opts))
            # rig frame contains the background only if passed; composite explicitly.
            scene=bg.copy(); scene.alpha_composite(frame)
            scene=_apply_camera(scene, camera or {}, u)
            scene.convert("RGB").save(frames/f"frame_{i:06d}.jpg",quality=95)
        cmd=[ffmpeg,"-y","-framerate",str(fps),"-i",str(frames/"frame_%06d.jpg"),"-t",str(duration),
             "-c:v","libx264","-preset","medium","-crf","18","-pix_fmt","yuv420p","-movflags","+faststart",str(output)]
        subprocess.run(cmd,check=True,capture_output=True,text=True)
        if not output.is_file() or output.stat().st_size==0: raise RuntimeError("FFmpeg produced no output")
    finally:
        if not keep_frames:
            shutil.rmtree(frames,ignore_errors=True)
    return output


def render_character_frames(background, parts, duration, canvas_size=(640,360), motion="idle",
                            start_xy=(0.5,0.72), path=None, fps=12, motion_options=None):
    """Pure-Python frame iterator, useful for previews and tests (yields PIL RGBA)."""
    W,H=canvas_size; bg=Image.open(background).convert("RGBA").resize((W,H)) if not isinstance(background,Image.Image) else background.convert("RGBA").resize((W,H))
    for i in range(max(1,math.ceil(duration*fps))):
        t=i/fps; pos=_path_position(path,min(1,t/max(duration,1e-9))) if path else start_xy
        rig=render_rig_frame(parts,(W,H),(int(pos[0]*W),int(pos[1]*H)),get_pose(motion,t,**(motion_options or {})))
        frame=bg.copy(); frame.alpha_composite(rig); yield frame
