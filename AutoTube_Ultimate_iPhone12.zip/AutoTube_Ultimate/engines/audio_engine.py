from utils.media_utils import audio_duration
def inspect_audio(path):
    return {"duration_seconds": audio_duration(path), "file": str(path)}
