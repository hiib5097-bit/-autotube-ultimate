"""Project workspace utilities for AutoTube's end-to-end production dashboard."""
from __future__ import annotations
import json, zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

WORKSPACE_VERSION = "1.0"

class WorkspaceError(ValueError):
    pass

def create_workspace(root: str | Path, name: str, *, aspect: str = "16:9", style: str = "2D Cartoon", quality: str = "Standard") -> dict[str, Any]:
    """Create a predictable project folder and manifest; safe for repeat calls."""
    if not name or not name.strip(): raise WorkspaceError("Project name cannot be empty")
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in name.strip()).strip("_")[:80]
    if not safe: raise WorkspaceError("Project name has no usable characters")
    if aspect not in {"16:9", "9:16", "1:1"}: raise WorkspaceError("aspect must be 16:9, 9:16, or 1:1")
    if style not in {"2D Cartoon", "Storybook 2D", "Comic 2D", "Documentary", "Cinematic 2.5D"}: raise WorkspaceError("Unsupported style")
    if quality not in {"Draft", "Standard", "High"}: raise WorkspaceError("Unsupported quality")
    p=Path(root)/safe
    for folder in ("audio","visuals","scenes","exports","references"): (p/folder).mkdir(parents=True,exist_ok=True)
    manifest={"schema_version":1,"autotube_version":WORKSPACE_VERSION,"project_name":name.strip(),"slug":safe,
      "created_at":datetime.now(timezone.utc).isoformat(),"settings":{"aspect":aspect,"style":style,"quality":quality},
      "status":"created","files":{"storyboard":"storyboard.json","prompts":"visual_prompts.json"}}
    write_json(p/"project.json",manifest)
    return manifest

def write_json(path: str | Path, data: Any) -> Path:
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding="utf-8")
    return path

def export_storyboard(project_dir: str | Path, scenes: list[dict], *, style: str = "2D Cartoon") -> dict[str, Path]:
    """Persist storyboard and one ready-to-copy image prompt per scene."""
    if not isinstance(scenes,list) or not scenes: raise WorkspaceError("Storyboard must contain at least one scene")
    normalized=[]; prompts=[]
    for i,scene in enumerate(scenes,1):
        narration=str(scene.get("narration","")).strip()
        if not narration: raise WorkspaceError(f"Scene {i} has empty narration")
        visual=str(scene.get("visual_prompt") or f"{style}, cinematic composition. Visualize: {narration}")
        row={**scene,"scene_id":scene.get("scene_id",i),"visual_prompt":visual}
        normalized.append(row); prompts.append({"scene_id":row["scene_id"],"start":row.get("start"),"end":row.get("end"),"prompt":visual})
    p=Path(project_dir)
    return {"storyboard":write_json(p/"storyboard.json",normalized),"prompts":write_json(p/"visual_prompts.json",prompts)}

def package_workspace(project_dir: str | Path, output_zip: str | Path) -> Path:
    """Zip a project workspace with relative paths, excluding temporary/cache files."""
    root=Path(project_dir).resolve(); target=Path(output_zip).resolve()
    if not root.is_dir(): raise WorkspaceError(f"Project folder not found: {root}")
    target.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED) as z:
        for f in sorted(root.rglob("*")):
            if f.is_file() and not any(x in f.parts for x in ("__pycache__",".pytest_cache")):
                z.write(f,f.relative_to(root))
    return target
