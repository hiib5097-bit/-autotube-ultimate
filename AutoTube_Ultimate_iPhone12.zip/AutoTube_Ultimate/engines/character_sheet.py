"""Character sheet utilities and prompts for external image providers."""
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
def character_prompt(description, style="2D cartoon"):
    return (f"Character turnaround sheet, {style}, one original character: {description}. "
            "Show front, side, three-quarter and back views plus 4 facial expressions. "
            "Plain neutral background, consistent proportions and clothing, clean outlines, no text.")
def make_contact_sheet(images, output, labels=None, cell=(400,400)):
    canvas=Image.new("RGB",(cell[0]*len(images),cell[1]),"white")
    draw=ImageDraw.Draw(canvas)
    for i,p in enumerate(images):
        im=Image.open(p).convert("RGBA"); im.thumbnail((cell[0]-20,cell[1]-50))
        x=i*cell[0]+(cell[0]-im.width)//2; y=(cell[1]-im.height)//2
        canvas.paste(im,(x,y),im)
        draw.text((i*cell[0]+10,cell[1]-28),(labels or [f"View {i+1}" for i in range(len(images))])[i],fill="black")
    canvas.save(output); return output
def split_rgba_layers(source, boxes, out_dir):
    """Crop user/provider-supplied segmentation boxes to transparent PNG parts.
    boxes: mapping name -> (left,top,right,bottom). Does not infer segmentation."""
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    im=Image.open(source).convert("RGBA")
    results={}
    for name,box in boxes.items():
        part=im.crop(tuple(map(int,box)))
        part.save(out/f"{name}.png"); results[name]=str(out/f"{name}.png")
    return results
