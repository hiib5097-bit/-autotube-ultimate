"""Composite transparent character/prop layers over backgrounds."""
from PIL import Image
def compose(background, layers, output, size=None):
    bg=Image.open(background).convert("RGBA")
    if size: bg=bg.resize(size)
    for layer in sorted(layers,key=lambda x:x.get("z",0)):
        im=Image.open(layer["image"]).convert("RGBA")
        if layer.get("size"): im=im.resize(tuple(layer["size"]))
        x,y=layer.get("xy",(0,0)); bg.alpha_composite(im,(int(x),int(y)))
    bg.save(output); return output
