# AutoTube Character Rig (MVP)
For puppet animation, prepare a transparent PNG for each part:
`torso.png`, `head.png`, `left_arm.png`, `right_arm.png`, `left_leg.png`, `right_leg.png`, optional `mouth.png`.
The rig engine renders RGBA layers and supports deterministic idle, walk and talk motion presets.
A production rig needs overlapping joint artwork (shoulder/elbow/hip) and pivots tuned to the character.
This is a functional procedural puppet renderer; automatic AI cutout/rigging is not yet included.
