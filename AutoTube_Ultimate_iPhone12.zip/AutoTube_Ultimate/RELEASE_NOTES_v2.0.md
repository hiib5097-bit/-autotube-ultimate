# AutoTube v2.0.0 — Integrated Starter Release

AutoTube v2.0 consolidates the starter modules into a versioned launch and validation entry point. It is a **functional starter/MVP**, not a claim that every scene is fully AI-animated autonomously.

## Launch

```bash
python -m pip install -r requirements.txt
python autotube.py
```

Windows: double-click `START_AUTOTUBE.bat` (Python must be installed). macOS/Linux: `./START_AUTOTUBE.command`.

## Included workflow

1. Upload a narration file in the Gradio dashboard.
2. Transcribe narration locally (Whisper model download may be required on first run).
3. Generate a narration-timed storyboard and scene prompts.
4. Supply an image-provider API key for generated scene art; otherwise the app uses narration/reference cards.
5. Animate still scenes with camera movement, create subtitles, mux narration, and export MP4.
6. Run basic QC and save a production report.

## CLI

- `python autotube.py --version`
- `python autotube.py check-project <project-folder>`

## Requirements / limitations

- FFmpeg must be available (the imageio-ffmpeg package can supply a bundled binary in many environments).
- Local Whisper may download a model on first transcription and needs adequate RAM/CPU.
- AI artwork requires a compatible image API key and provider access; no key means non-generative fallback visuals.
- This release does not promise fully rigged animal motion, perfect character consistency, or professional studio-grade 2.5D output from a single click. It uses still-art camera animation unless a user supplies rigged assets and uses the rig modules.
- Generated video quality depends on artwork, narration, system resources, and provider availability.
