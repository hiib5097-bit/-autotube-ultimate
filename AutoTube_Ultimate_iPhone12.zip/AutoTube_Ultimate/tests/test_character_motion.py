import math
import pytest
from engines.character_motion import idle, walk, run, talk, wave, get_pose


def test_walk_is_periodic_and_has_opposing_limbs():
    a, b = walk(0.0), walk(0.5)
    assert a[1]["rotation"] == pytest.approx(b[1]["rotation"], abs=1e-6)
    assert a[1]["rotation"] == -a[2]["rotation"]
    assert a[3]["rotation"] == -a[4]["rotation"]


def test_run_has_larger_limb_swing_than_walk():
    assert abs(run(.25)[1]["rotation"]) > abs(walk(.25)[1]["rotation"])


def test_talk_includes_mouth_pulse():
    assert talk(.1)[5]["scale"] != talk(.2)[5]["scale"]


def test_wave_arm_raises_and_moves():
    assert wave(.5)[1]["rotation"] < 0
    assert wave(1.0)[1]["rotation"] != wave(.5)[1]["rotation"]


def test_unknown_motion_is_actionable():
    with pytest.raises(ValueError, match="Unknown character motion"):
        get_pose("fly", 0)
