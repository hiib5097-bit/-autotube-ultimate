import json
from pathlib import Path
from PIL import Image
import pytest
from engines.scene_animation_engine import render_storyboard


def test_storyboard_validates_missing_assets(tmp_path):
    with pytest.raises(ValueError,match="background"):
        render_storyboard([{"scene_id":1,"duration":1,"background":"bg",
          "character":{"parts":[{"image":"body"}]}}],{},tmp_path)


def test_storyboard_renders_clip_and_manifest(tmp_path,monkeypatch):
    bg=tmp_path/"bg.png"; part=tmp_path/"part.png"
    Image.new("RGBA",(80,60),(10,20,30,255)).save(bg)
    Image.new("RGBA",(20,20),(220,40,40,255)).save(part)
    # Exercise orchestration without depending on an installed FFmpeg binary.
    captured={}
    def fake_render(background,parts,output,duration,**kwargs):
        captured.update(kwargs)
        Path(output).write_bytes(b"fake mp4"); return Path(output)
    monkeypatch.setattr("engines.scene_animation_engine.render_character_scene",fake_render)
    result=render_storyboard([{"scene_id":"A","start":0,"end":2,"background":"bg",
      "narration":"hello","camera":{"start_zoom":1,"end_zoom":1.2},"character":{"motion":"walk","parts":[{"image":"body","z":1}]}}],
      {"bg":bg,"body":part},tmp_path/"clips")
    assert result["count"]==1 and result["total_duration"]==2
    assert captured["camera"]["end_zoom"]==1.2
    assert Path(result["scenes"][0]["clip"]).read_bytes()==b"fake mp4"
    data=json.loads(Path(result["manifest"]).read_text())
    assert data[0]["scene_id"]=="A"
