import unittest
from engines.animation_timeline import AnimationTimeline, Track

class TimelineTests(unittest.TestCase):
    def test_clamps_and_interpolates(self):
        t=Track('x',[{'time':0,'value':0,'easing':'linear'},{'time':2,'value':10,'easing':'linear'}])
        self.assertEqual(t.value_at(-1),0); self.assertEqual(t.value_at(3),10)
        self.assertEqual(t.value_at(1),5)
    def test_vector_interpolation(self):
        t=Track('position',[{'time':0,'value':[0,2],'easing':'linear'},{'time':1,'value':[10,4],'easing':'linear'}])
        self.assertEqual(t.value_at(.5),[5,3])
    def test_timeline_evaluate_and_sample(self):
        tl=AnimationTimeline(1,[Track('opacity',[{'time':0,'value':0,'easing':'linear'},{'time':1,'value':1,'easing':'linear'}])])
        self.assertEqual(tl.evaluate(.5),{'opacity':.5})
        self.assertEqual(len(tl.sample(10)),10)
    def test_duplicate_times_rejected(self):
        with self.assertRaises(ValueError): Track('x',[{'time':0,'value':0},{'time':0,'value':1}])

if __name__=='__main__': unittest.main()
