import base64, json, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
from providers.image_provider import ImageProvider, OpenAICompatibleImageProvider

class Response:
    def __init__(self, body): self.body=body
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def read(self): return self.body

class ProviderTests(unittest.TestCase):
    def test_base_provider_is_contract(self):
        with self.assertRaises(NotImplementedError): ImageProvider().generate("x","y")
    def test_requires_key(self):
        with self.assertRaises(ValueError): OpenAICompatibleImageProvider(api_key="")
    def test_generates_and_saves_b64(self):
        raw=b"\x89PNG\r\n"+b"x"*200
        body=json.dumps({"data":[{"b64_json":base64.b64encode(raw).decode()}]}).encode()
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"art.png"
            with patch("urllib.request.urlopen",return_value=Response(body)) as call:
                provider=OpenAICompatibleImageProvider(api_key="secret")
                self.assertEqual(provider.generate("orca underwater",p),str(p))
                self.assertEqual(p.read_bytes(),raw)
                req=call.call_args.args[0]
                self.assertEqual(json.loads(req.data)["prompt"],"orca underwater")
                self.assertEqual(req.headers["Authorization"],"Bearer secret")
    def test_api_error_is_actionable(self):
        import urllib.error
        err=urllib.error.HTTPError("url",401,"unauthorized",{},None); err.read=lambda:b'{"error":"bad key"}'
        with tempfile.TemporaryDirectory() as td, patch("urllib.request.urlopen",side_effect=err):
            with self.assertRaisesRegex(RuntimeError,"HTTP 401"):
                OpenAICompatibleImageProvider(api_key="bad").generate("test",Path(td)/"a.png")
    def test_empty_response_rejected(self):
        with tempfile.TemporaryDirectory() as td, patch("urllib.request.urlopen",return_value=Response(b'{"data":[]}')):
            with self.assertRaisesRegex(RuntimeError,"no image data"):
                OpenAICompatibleImageProvider(api_key="secret").generate("test",Path(td)/"a.png")

if __name__=="__main__": unittest.main()
