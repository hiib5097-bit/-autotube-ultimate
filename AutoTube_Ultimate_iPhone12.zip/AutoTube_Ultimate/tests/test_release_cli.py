import json
from pathlib import Path
import pytest
from autotube import VERSION, validate_project, main

def test_release_version():
    assert VERSION == "ULTIMATE 3.0.0"

def test_validate_project(tmp_path):
    (tmp_path/"project.json").write_text(json.dumps({"project_name":"Demo","settings":{}}))
    report=validate_project(tmp_path)
    assert report["project_name"]=="Demo"
    assert report["checks"]=={"storyboard":False,"prompts":False}

def test_missing_project_manifest(tmp_path):
    with pytest.raises(ValueError): validate_project(tmp_path)

def test_missing_project_folder():
    with pytest.raises(FileNotFoundError): validate_project("/definitely/not/a/project")

def test_cli_check_project(tmp_path,capsys):
    (tmp_path/"project.json").write_text(json.dumps({"project_name":"Demo"}))
    assert main(["check-project",str(tmp_path)])==0
    assert "Demo" in capsys.readouterr().out
