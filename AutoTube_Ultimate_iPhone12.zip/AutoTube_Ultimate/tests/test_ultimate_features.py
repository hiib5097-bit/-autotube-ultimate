import json
from pathlib import Path
from PIL import Image, ImageDraw
from engines.story_pacing import plan_storyboard
from engines.auto_rigging import extract_parts, validate_rig_folder


def test_ultimate_script_planner_produces_continuous_storyboard():
    rows = plan_storyboard("A shark moves through the dark ocean while fish scatter and the current shifts around its powerful body.\n\nOrcas arrive silently from the distant horizon and begin circling the predator with coordinated movements.", max_words_per_scene=12)
    assert len(rows) >= 2
    assert rows[0]["start"] == 0
    assert rows[1]["start"] == rows[0]["end"]
    assert all(r["visual_prompt"] and r["duration"] > 0 for r in rows)


def test_ultimate_rig_extract_and_manifest(tmp_path):
    sheet = Image.new("RGBA", (200, 300), (0, 0, 0, 0))
    draw = ImageDraw.Draw(sheet)
    draw.ellipse((70, 15, 130, 75), fill=(220, 100, 40, 255))
    draw.rectangle((65, 75, 135, 190), fill=(40, 120,220,255))
    draw.rectangle((25, 80, 70, 150), fill=(40,120,220,255))
    draw.rectangle((130,80,175,150), fill=(40,120,220,255))
    draw.rectangle((70,180,95,285), fill=(40,120,220,255))
    draw.rectangle((105,180,130,285), fill=(40,120,220,255))
    src=tmp_path/"sheet.png"; sheet.save(src)
    regions={"torso":[.25,.24,.75,.66],"head":[.30,.02,.70,.27],"left_arm":[.05,.25,.38,.52],"right_arm":[.62,.25,.95,.52],"left_leg":[.30,.60,.49,.98],"right_leg":[.51,.60,.70,.98]}
    out=tmp_path/"rig"; manifest=extract_parts(src,out,regions)
    assert len(manifest["parts"]) == 6
    assert (out/"rig_manifest.json").exists()
    assert not validate_rig_folder(out)
