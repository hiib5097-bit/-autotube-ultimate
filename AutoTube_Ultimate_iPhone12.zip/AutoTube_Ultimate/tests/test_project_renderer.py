from pathlib import Path
import json
import pytest
from engines import project_renderer


def test_project_renderer_connects_scene_and_final_assembly(tmp_path,monkeypatch):
    audio=tmp_path/"voice.wav"; audio.write_bytes(b"audio")
    scene_clip=tmp_path/"scene.mp4"; scene_clip.write_bytes(b"clip")
    def fake_storyboard(*args,**kwargs):
        return {"scenes":[{"clip":str(scene_clip),"duration":2}],"count":1,
                "total_duration":2,"manifest":"manifest.json"}
    def fake_assemble(clips,audio,output,srt=None,vertical=False):
        Path(output).write_bytes(b"final-video"); return Path(output)
    monkeypatch.setattr(project_renderer,"render_storyboard",fake_storyboard)
    monkeypatch.setattr(project_renderer,"assemble_video",fake_assemble)
    result=project_renderer.render_project([],{},audio,tmp_path/"final.mp4")
    assert result["status"]=="complete" and result["scene_count"]==1
    assert Path(result["output"]).read_bytes()==b"final-video"
    assert json.loads(Path(result["report"]).read_text())["status"]=="complete"


def test_project_renderer_checks_audio(tmp_path):
    with pytest.raises(FileNotFoundError,match="Narration audio"):
        project_renderer.render_project([],{},tmp_path/"missing.wav",tmp_path/"out.mp4")
