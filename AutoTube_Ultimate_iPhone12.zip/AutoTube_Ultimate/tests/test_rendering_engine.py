from pathlib import Path
import shutil
import subprocess
import pytest
from engines.rendering_engine import render

@pytest.mark.skipif(not shutil.which('ffmpeg'), reason='FFmpeg unavailable')
def test_render_two_generated_clips(tmp_path):
    clips=[]
    for i,color in enumerate(['red','blue']):
        p=tmp_path/f'clip{i}.mp4'
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',f'color=c={color}:s=320x240:r=24:d=0.5','-c:v','libx264','-pix_fmt','yuv420p',str(p)],check=True)
        clips.append(p)
    audio=tmp_path/'tone.wav'
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=frequency=440:duration=1','-c:a','pcm_s16le',str(audio)],check=True)
    out=render(clips,audio,tmp_path/'final.mp4')
    assert out.exists() and out.stat().st_size>1000
    probe=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(out)],capture_output=True,text=True,check=True)
    assert float(probe.stdout.strip())>=0.8

def test_render_rejects_empty_scene_list(tmp_path):
    with pytest.raises(ValueError,match='no scene clips'):
        render([],tmp_path/'audio.wav',tmp_path/'out.mp4')
