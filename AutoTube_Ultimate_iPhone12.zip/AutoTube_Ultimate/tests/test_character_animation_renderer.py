from PIL import Image, ImageDraw
from engines.rig_engine import Part
from engines.character_animation_renderer import _path_position, render_character_frames


def test_path_interpolation():
    assert _path_position([(0,0),(1,1)],.5)==(.5,.5)
    assert _path_position([(0,0)],.8)==(0,0)


def test_frame_generator_composites_character(tmp_path):
    bg=Image.new('RGBA',(100,100),(10,20,30,255)); bgp=tmp_path/'bg.png'; bg.save(bgp)
    sprite=Image.new('RGBA',(20,30),(0,0,0,0)); ImageDraw.Draw(sprite).rectangle((2,2,18,28),fill=(255,0,0,255))
    sp=tmp_path/'body.png'; sprite.save(sp)
    part=Part(str(sp),pivot=(.5,.5),offset=(0,0),z=0)
    frames=list(render_character_frames(bgp,[part],duration=.25,canvas_size=(100,100),fps=4,start_xy=(.5,.5)))
    assert len(frames)==1
    assert frames[0].getpixel((50,50))[0] > 200
    assert frames[0].getpixel((0,0))==(10,20,30,255)
