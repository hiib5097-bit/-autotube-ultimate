import json, zipfile
import pytest
from engines.production_workspace import create_workspace, export_storyboard, package_workspace, WorkspaceError

def test_create_workspace_structure_and_manifest(tmp_path):
    m=create_workspace(tmp_path,"My Animal Film",aspect="9:16")
    p=tmp_path/m["slug"]
    assert (p/"visuals").is_dir() and (p/"exports").is_dir()
    assert json.loads((p/"project.json").read_text())["settings"]["aspect"]=="9:16"

def test_reject_invalid_project_settings(tmp_path):
    with pytest.raises(WorkspaceError): create_workspace(tmp_path," ")
    with pytest.raises(WorkspaceError): create_workspace(tmp_path,"X",aspect="4:3")

def test_export_storyboard_and_prompts(tmp_path):
    paths=export_storyboard(tmp_path,[{"scene_id":1,"start":0,"end":4,"narration":"A shark swims."}],style="Documentary")
    prompts=json.loads(paths["prompts"].read_text())
    assert "Documentary" in prompts[0]["prompt"]

def test_package_workspace_excludes_cache(tmp_path):
    p=tmp_path/"project"; p.mkdir(); (p/"hello.txt").write_text("ok")
    (p/"__pycache__").mkdir(); (p/"__pycache__"/"bad.pyc").write_bytes(b"x")
    z=package_workspace(p,tmp_path/"out.zip")
    with zipfile.ZipFile(z) as archive: assert archive.namelist()==["hello.txt"]
