import pytest
from engines.composition_engine import camera_preset, auto_compose


def test_presets_have_renderer_parameters():
    cam = camera_preset("slow_push")
    assert cam["start_zoom"] == 1.0 and cam["end_zoom"] > 1.0
    assert len(cam["start_pan"]) == 2


def test_auto_camera_uses_subject_bias():
    left = camera_preset("dramatic", (0.2, 0.7))
    right = camera_preset("dramatic", (0.8, 0.7))
    assert left["start_pan"][0] < right["start_pan"][0]


def test_auto_compose_resolves_auto_fields():
    scene = {"camera": "auto", "camera_style": "slow_pull",
             "character": {"start_xy": "auto"}}
    out = auto_compose(scene)
    assert out["character"]["start_xy"] == (0.5, 0.72)
    assert out["camera"]["preset"] == "slow_pull"
    assert scene["camera"] == "auto"  # input remains untouched


def test_invalid_preset_and_position_fail_clearly():
    with pytest.raises(ValueError, match="Unknown camera"):
        camera_preset("wild")
    with pytest.raises(ValueError, match="normalized"):
        camera_preset("static", (2, 0.5))
