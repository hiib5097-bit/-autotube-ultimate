import pytest
from engines.story_pacing import estimate_speech_duration, split_narration, plan_storyboard

def test_duration_estimate_increases_with_words():
    assert estimate_speech_duration('one two three') > estimate_speech_duration('one')

def test_bad_wpm_rejected():
    with pytest.raises(ValueError): estimate_speech_duration('words', 0)

def test_empty_script_has_no_scenes():
    assert plan_storyboard('  ') == []

def test_planner_outputs_contiguous_timing_and_prompts():
    rows=plan_storyboard('The ocean is dark.\n\nA shark moves silently through the water.', max_words_per_scene=8)
    assert len(rows)>=2
    assert rows[0]['start']==0
    assert rows[1]['start']==rows[0]['end']
    assert all(r['duration']>0 and r['visual_prompt'] for r in rows)

def test_split_respects_scene_word_limit_approximately():
    chunks=split_narration('One two three four five six seven eight nine ten. Eleven twelve thirteen fourteen fifteen.',max_words=8)
    assert len(chunks)>=2
