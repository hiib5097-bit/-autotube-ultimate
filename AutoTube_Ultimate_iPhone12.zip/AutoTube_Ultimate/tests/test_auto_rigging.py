import json
from PIL import Image, ImageDraw
import pytest
from engines.auto_rigging import extract_parts, validate_rig_folder, RigPreparationError

def test_extract_parts_and_manifest(tmp_path):
    src=tmp_path/'sheet.png'; im=Image.new('RGBA',(100,100)); ImageDraw.Draw(im).rectangle((20,20,80,80),fill='red'); im.save(src)
    out=tmp_path/'rig'; m=extract_parts(src,out,{'torso':(.2,.2,.8,.8),'head':(.4,.2,.6,.4)})
    assert (out/'torso.png').exists() and (out/'head.png').exists()
    assert json.loads((out/'rig_manifest.json').read_text())['parts']['torso']['file']=='torso.png'
    assert m['canvas']==[100,100]

def test_invalid_region(tmp_path):
    src=tmp_path/'s.png'; Image.new('RGBA',(10,10),(255,0,0,255)).save(src)
    with pytest.raises(RigPreparationError): extract_parts(src,tmp_path/'o',{'head':(.8,.2,.1,.9)})

def test_validate_required_parts(tmp_path):
    assert len(validate_rig_folder(tmp_path))==7
