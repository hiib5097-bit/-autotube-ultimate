import tempfile, unittest
from pathlib import Path
from engines.character_continuity import create_profile, save_profiles, load_profiles, attach_reference, scene_prompt, validate_scene_characters

class ContinuityTests(unittest.TestCase):
 def test_profile_and_persistence(self):
  p=create_profile('Orca','black-and-white killer whale',traits=['white eye patch','notched dorsal fin'])
  with tempfile.TemporaryDirectory() as d:
   save_profiles(d,{'orca':p}); self.assertEqual(load_profiles(d)['orca']['traits'],p['traits'])
 def test_reference_copy(self):
  with tempfile.TemporaryDirectory() as d:
   src=Path(d)/'ref.png'; src.write_bytes(b'fake-image')
   p=attach_reference(create_profile('Fox','red fox'),src,d,'fox')
   self.assertTrue(Path(p['reference']).exists())
 def test_prompt_identity(self):
  p={'orca':create_profile('Orca','black body, white eye patch')}
  result=scene_prompt('Hunting underwater',['orca'],p,continuity_notes='same ocean location')
  self.assertIn('white eye patch',result); self.assertIn('same ocean location',result)
 def test_missing_profile_warning(self):
  self.assertEqual(validate_scene_characters([{'scene_id':4,'characters':['fox']}],{}),[{'scene':4,'character':'fox','issue':'missing_profile'}])
 def test_unknown_character_prompt_errors(self):
  with self.assertRaises(KeyError): scene_prompt('x',['missing'],{})
if __name__=='__main__': unittest.main()
