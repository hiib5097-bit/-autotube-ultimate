from PIL import Image
import pytest
from engines.character_animation_renderer import _apply_camera


def test_camera_zoom_and_pan_return_canvas_size():
    image=Image.new('RGBA',(100,60),(30,40,50,255))
    result=_apply_camera(image,{'start_zoom':1.0,'end_zoom':1.5,'start_pan':(0,0),'end_pan':(.2,-.1)},1)
    assert result.size==(100,60)


def test_camera_rejects_nonpositive_zoom():
    with pytest.raises(ValueError,match='zoom'):
        _apply_camera(Image.new('RGBA',(10,10)),{'start_zoom':0},0)


def test_no_camera_is_identity():
    image=Image.new('RGBA',(20,20),(1,2,3,4))
    assert _apply_camera(image,{},.5) is image
