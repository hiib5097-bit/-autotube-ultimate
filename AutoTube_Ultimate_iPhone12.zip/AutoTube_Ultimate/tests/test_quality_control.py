import json
from pathlib import Path
from engines.quality_control import inspect_mp4, inspect_video, write_qc_report, _subtitle_end


def test_missing_video_fails(tmp_path):
    result = inspect_video(tmp_path / "missing.mp4", run_content_checks=False)
    assert result["status"] == "failed"
    assert result["errors"]


def test_subtitle_end_parsing(tmp_path):
    srt = tmp_path / "x.srt"
    srt.write_text("1\n00:00:01,000 --> 00:00:03,500\nHello\n\n2\n00:00:04,000 --> 00:00:05,250\nWorld\n")
    assert _subtitle_end(srt) == 5.25


def test_write_report(tmp_path):
    p = write_qc_report({"status": "passed"}, tmp_path / "qc.json")
    assert json.loads(Path(p).read_text())["status"] == "passed"
