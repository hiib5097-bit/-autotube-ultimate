# AutoTube Ultimate 3.0 — Consolidated release

This release consolidates the existing production engine and adds a unified dashboard with four tabs: Voiceover production, script-to-storyboard planning, character rig preparation, and export QC.

## Added in Ultimate
- One dashboard with production, planning, rig prep, and QC.
- Character rig region editor (JSON normalized crop boxes), layer contact-sheet preview, ZIP export.
- Optional rembg call from rig UI.
- Script storyboard preview + JSON download.
- MP4 QC report download.
- Updated launcher/version and consolidated documentation.

## Limitations stated in UI
Generative scene artwork needs an image API; character cutout/rigging is semi-automatic and crop-based; current animation is puppet/camera-motion based, not autonomous high-end 2.5D or motion-video generation.
