from pathlib import Path
import shutil, uuid
from config import PROJECTS
def new_project():
    p = PROJECTS / f"project_{uuid.uuid4().hex[:8]}"
    p.mkdir(parents=True)
    return p
def copy_into(src, dst):
    dst=Path(dst); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst); return dst
