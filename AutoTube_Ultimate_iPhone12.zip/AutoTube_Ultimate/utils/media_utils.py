import subprocess, shutil
def require_ffmpeg():
    if not shutil.which("ffmpeg"): raise RuntimeError("FFmpeg not found. Install it with: apt-get install ffmpeg")
def audio_duration(path):
    require_ffmpeg()
    out=subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",str(path)],text=True)
    return float(out.strip())
