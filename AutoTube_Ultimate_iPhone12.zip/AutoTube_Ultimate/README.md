# AutoTube Ultimate — Consolidated Production Studio (3.0)

AutoTube Ultimate brings the production workflow and creator utilities into one Gradio dashboard. This is a **usable, extensible production application**, not a claim that every stage is fully autonomous or that all AI providers are bundled.

## Launch

1. Install Python 3.10+ and FFmpeg (ensure `ffmpeg` and `ffprobe` are on PATH).
2. Install dependencies: `python -m pip install -r requirements.txt`.
3. Launch: `python autotube.py` (or `python app.py`).
4. Open the local URL printed by Gradio (normally `http://127.0.0.1:7860`).
   - Windows: double-click `START_AUTOTUBE.bat`.
   - macOS/Linux: `./START_AUTOTUBE.command`.

## Dashboard tabs

### 1. Video Production
Upload a voiceover (MP3/WAV), choose format and visual style, optionally add a reference image and an image API key, and run the production pipeline. It transcribes locally with faster-whisper, creates scene beats and SRT captions, generates scene art through an OpenAI-compatible Images API when configured, animates each still with camera movement, assembles narration/subtitles, and exports MP4 plus a report. Without image credentials, it uses a clearly disclosed narration-card/reference-image visual fallback.

**Image generation:** optional provider key; defaults are `IMAGE_API_BASE=https://api.openai.com/v1` and `IMAGE_MODEL=gpt-image-1`. Image generation may incur provider charges. Keys are used in memory and are not intentionally written into project files.

### 2. Script → Storyboard
Paste text to create scene-sized chunks, estimated duration, continuous timestamps, visual prompts and transitions. Download the JSON for editing. Timing is estimated from words/punctuation; it is not forced alignment to audio.

### 3. Character Rig Studio
Upload a character sheet and edit normalized crop regions `(x0,y0,x1,y1)` from 0 to 1. Crop boxes should overlap at joints. The tool extracts transparent PNG layers, creates `rig_manifest.json`, previews the layers, and packages them as a ZIP. Optional background removal requires `pip install rembg`.

**Rigging is semi-automatic:** regions and pivots need human adjustment; generic cropping does not infer anatomy, joint artwork, or animation-ready cutouts from arbitrary images. A clean transparent character sheet with joint overlap gives better results.

### 4. Export Quality Control
Inspect an MP4 for stream/probe errors, duration, subtitle bounds, black segments and long audio silence. Findings are saved as JSON. Content detections are review warnings, not perfect automated creative judgment.

## Engine capabilities

- Narration transcription and subtitle creation.
- Deterministic script/storyboard pacing.
- API-backed scene artwork (provider-dependent).
- Character identity/continuity prompt helpers.
- Transparent puppet-part rendering and procedural idle/walk/run/talk/wave poses.
- Ken Burns pan/zoom, cinematic camera presets, fades and scene assembly.
- Narration mux, MP4 export, QC and project reports.
- Project workspace and storyboard/prompt exports.

## Important limitations

- Not an autonomous text-to-finished-film system: human review and asset setup remain necessary.
- Still artwork + camera movement is not full 2.5D depth animation or generated motion video.
- AI artwork depends on a configured compatible provider and network/API availability.
- Character rig extraction is region-based; fully automatic anatomical segmentation/rigging is not included.
- Voiceover timing is approximate unless manually aligned to the waveform.
- Production quality setting is currently a UI preset and not every encoder control is wired to it.

## CLI

`python autotube.py --version` reports the release. `python autotube.py check-project <folder>` validates a project manifest.

## Tests

Run `PYTHONPATH=. pytest -q` from this folder.
