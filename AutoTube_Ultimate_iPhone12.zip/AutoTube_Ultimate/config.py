import os
from pathlib import Path
ROOT = Path(__file__).resolve().parent
PROJECTS = ROOT / "projects"
OUTPUTS = ROOT / "outputs"
ASSETS = ROOT / "assets"
LOGS = ROOT / "logs"
for p in (PROJECTS, OUTPUTS, ASSETS, LOGS): p.mkdir(parents=True, exist_ok=True)
WHISPER_MODEL = os.getenv("AUTOTUBE_WHISPER_MODEL", "base")
IMAGE_API_KEY = os.getenv("IMAGE_API_KEY", "")
VIDEO_API_KEY = os.getenv("VIDEO_API_KEY", "")
TRANSCRIPTION_API_KEY = os.getenv("TRANSCRIPTION_API_KEY", "")
