# Install AutoTube Ultimate

## Windows
1. Install Python 3.10 or newer and FFmpeg. During Python setup, tick **Add Python to PATH**.
2. Extract the ZIP to a folder.
3. Double-click `START_AUTOTUBE.bat` (first launch installs Python packages).
4. Open the local Gradio address printed in the terminal.

## macOS / Linux
1. Install Python 3.10+, FFmpeg, and ensure `ffmpeg`/`ffprobe` are on PATH.
2. In this folder run `python3 -m pip install -r requirements.txt`.
3. Run `python3 autotube.py` or `./START_AUTOTUBE.command`.

## Optional AI image generation
Enter a supported image API key in the Video Production tab. It may incur provider costs. Leave blank to use the fallback visual cards/reference visuals.

## Character rigging
Upload an image, edit the crop coordinates to match your character, and generate a rig ZIP. This tool crops layers; it does not automatically discover anatomy or animate joints perfectly. Optional background removal: `python -m pip install rembg`.

## Troubleshooting
- `ffmpeg not found`: install FFmpeg and add its `bin` directory to PATH, then restart the terminal.
- Transcription first run: faster-whisper downloads model weights; allow network access and disk space.
- Out-of-memory: use a smaller Whisper model via `WHISPER_MODEL` in `config.py` or choose a smaller local workflow.
- API error: verify endpoint/model/key and provider image-generation support.
