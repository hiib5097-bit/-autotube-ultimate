"""AutoTube Ultimate release launcher and project utilities."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

VERSION = "ULTIMATE 3.0.0"

def validate_project(path: str | Path) -> dict:
    p=Path(path).expanduser().resolve()
    if not p.is_dir(): raise FileNotFoundError(f"Project folder does not exist: {p}")
    manifest=p/"project.json"
    if not manifest.is_file(): raise ValueError("Missing project.json. Create a project from the dashboard first.")
    data=json.loads(manifest.read_text(encoding="utf-8"))
    if not isinstance(data,dict) or not data.get("project_name"): raise ValueError("Invalid project manifest")
    checks={"storyboard":p/"storyboard.json","prompts":p/"visual_prompts.json"}
    data["checks"]={k: v.exists() for k,v in checks.items()}
    data["project_path"]=str(p)
    return data

def main(argv=None):
    parser=argparse.ArgumentParser(prog="autotube",description="AutoTube Ultimate AI Video Production Engine")
    parser.add_argument("--version",action="version",version=f"AutoTube {VERSION}")
    sub=parser.add_subparsers(dest="command")
    check=sub.add_parser("check-project",help="Validate a project folder")
    check.add_argument("project")
    args=parser.parse_args(argv)
    if args.command=="check-project":
        try:
            report=validate_project(args.project); print(json.dumps(report,indent=2)); return 0
        except Exception as exc: print(f"Project check failed: {exc}",file=sys.stderr); return 2
    try:
        import app
        app.demo.launch()
        return 0
    except Exception as exc:
        print(f"Unable to launch dashboard: {exc}\nInstall dependencies with: python -m pip install -r requirements.txt",file=sys.stderr)
        return 1

if __name__=="__main__": raise SystemExit(main())
