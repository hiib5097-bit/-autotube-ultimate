"""Image-generation providers for AutoTube.

The OpenAI-compatible provider uses the Images API. API credentials are passed
at runtime and are never written to project files or logs.
"""
from __future__ import annotations
import base64
import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

class ImageProvider:
    """Provider contract. Implement generate(prompt, output_path, reference)."""
    def generate(self, prompt, output_path, reference=None):
        raise NotImplementedError("No image provider configured. Choose an API-backed implementation.")

class OpenAICompatibleImageProvider(ImageProvider):
    """Generate images using an OpenAI-compatible /v1/images/generations API."""
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None,
                 model: Optional[str] = None, size: str = "1536x1024", quality: str = "medium",
                 timeout: int = 180):
        self.api_key = api_key or os.getenv("IMAGE_API_KEY", "")
        self.base_url = (base_url or os.getenv("IMAGE_API_BASE", "https://api.openai.com/v1")).rstrip("/")
        self.model = model or os.getenv("IMAGE_MODEL", "gpt-image-1")
        self.size, self.quality, self.timeout = size, quality, timeout
        if not self.api_key: raise ValueError("Image API key is required (IMAGE_API_KEY).")

    def generate(self, prompt, output_path, reference=None):
        if not isinstance(prompt, str) or not prompt.strip(): raise ValueError("Image prompt cannot be empty.")
        if reference:
            # Reference-image editing is intentionally explicit; unsupported providers
            # return a useful error instead of silently ignoring the reference.
            return self._edit(prompt, output_path, reference)
        payload = {"model": self.model, "prompt": prompt, "size": self.size,
                   "quality": self.quality, "n": 1}
        data = self._request("POST", "/images/generations", payload)
        self._save_result(data, output_path)
        return str(Path(output_path))

    def _edit(self, prompt, output_path, reference):
        # OpenAI image edits require multipart/form-data.
        boundary = "----AutoTubeBoundary7MA4YWxkTrZu0gW"
        fields = {"model": self.model, "prompt": prompt, "size": self.size, "n": "1"}
        chunks=[]
        for key,value in fields.items():
            chunks.extend([f"--{boundary}\r\nContent-Disposition: form-data; name=\"{key}\"\r\n\r\n{value}\r\n".encode()])
        path=Path(reference)
        if not path.is_file(): raise FileNotFoundError(f"Reference image not found: {reference}")
        mime="image/png" if path.suffix.lower()==".png" else "image/jpeg"
        chunks.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"image\"; filename=\"{path.name}\"\r\nContent-Type: {mime}\r\n\r\n".encode())
        chunks.append(path.read_bytes()); chunks.append(f"\r\n--{boundary}--\r\n".encode())
        raw=b"".join(chunks)
        req=urllib.request.Request(self.base_url+"/images/edits",data=raw,method="POST",
             headers={"Authorization":f"Bearer {self.api_key}","Content-Type":f"multipart/form-data; boundary={boundary}"})
        data=self._open_json(req); self._save_result(data,output_path); return str(Path(output_path))

    def _request(self, method, endpoint, payload):
        req=urllib.request.Request(self.base_url+endpoint,data=json.dumps(payload).encode(),method=method,
          headers={"Authorization":f"Bearer {self.api_key}","Content-Type":"application/json"})
        return self._open_json(req)

    def _open_json(self, request):
        try:
            with urllib.request.urlopen(request,timeout=self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail=exc.read().decode("utf-8",errors="replace")[:1200]
            raise RuntimeError(f"Image API HTTP {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Could not reach image API: {exc.reason}") from exc

    @staticmethod
    def _save_result(data, output_path):
        items=data.get("data") or []
        if not items: raise RuntimeError("Image API returned no image data.")
        item=items[0]; path=Path(output_path); path.parent.mkdir(parents=True,exist_ok=True)
        if item.get("b64_json"):
            path.write_bytes(base64.b64decode(item["b64_json"],validate=True))
        elif item.get("url"):
            req=urllib.request.Request(item["url"],headers={"User-Agent":"AutoTube/1.1"})
            with urllib.request.urlopen(req,timeout=180) as response: path.write_bytes(response.read())
        else: raise RuntimeError("Image API response had neither b64_json nor url.")
        if path.stat().st_size < 100: raise RuntimeError("Image API produced an unexpectedly small image file.")
