class VideoProvider:
    """Provider contract. Implement generate(prompt, duration, output_path, reference=None)."""
    def generate(self, prompt, duration, output_path, reference=None):
        raise NotImplementedError("No AI video provider configured; use the built-in 2D motion fallback.")
