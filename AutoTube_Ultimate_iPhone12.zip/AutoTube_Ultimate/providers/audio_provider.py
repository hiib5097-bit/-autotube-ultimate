class AudioProvider:
    """Optional contract for generated music/SFX."""
    def generate(self, prompt, duration, output_path):
        raise NotImplementedError("No audio-generation provider configured.")
