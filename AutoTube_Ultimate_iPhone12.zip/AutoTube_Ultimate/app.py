import os, shutil, traceback, tempfile
from pathlib import Path
import gradio as gr
from config import OUTPUTS
from engines.audio_engine import inspect_audio
from engines.transcription_engine import transcribe
from engines.story_engine import sentence_chunks
from engines.storyboard_engine import make_storyboard
from engines.subtitle_engine import write_srt
from engines.sound_engine import mix_audio
from engines.quality_control import inspect_mp4

def production(audio, reference, fmt, style, quality, burn_subs, image_api_key, progress=gr.Progress()):
    if not audio: raise gr.Error("Upload an MP3 or WAV voiceover first.")
    project=OUTPUTS.parent/"projects"/("run_"+Path(audio).stem.replace(" ","_"))
    project.mkdir(parents=True,exist_ok=True)
    try:
        progress(0.05,desc="Inspecting voiceover")
        info=inspect_audio(audio)
        progress(0.15,desc="Transcribing narration (local Whisper)")
        transcript=transcribe(audio)
        import json
        (project/"transcript.json").write_text(json.dumps(transcript,indent=2),encoding="utf-8")
        scenes=make_storyboard(sentence_chunks(transcript))
        # Apply the selected visual language consistently to every scene prompt.
        style_prefix={"2D Cartoon":"2D cartoon, bold readable silhouettes, expressive shapes",
                     "Storybook 2D":"storybook illustration, painterly 2D, warm cinematic lighting",
                     "Comic 2D":"comic-book 2D, ink outlines, dramatic framing"}.get(style,style)
        for scene in scenes:
            scene["visual_prompt"]=f"{style_prefix}; cinematic composition; visualize: {scene['narration']}"
        (project/"storyboard.json").write_text(json.dumps(scenes,indent=2),encoding="utf-8")
        progress(0.3,desc="Preparing visual scenes")
        # MVP uses a deliberately explicit placeholder visual only if no image provider is configured.
        # User reference is used as scene artwork; otherwise produce a clean illustrated text card.
        from PIL import Image, ImageDraw, ImageFont
        W,H=(1080,1920) if fmt=="Shorts (9:16)" else (1920,1080)
        scene_files=[]
        image_provider=None
        if image_api_key and image_api_key.strip():
            from providers.image_provider import OpenAICompatibleImageProvider
            image_provider=OpenAICompatibleImageProvider(api_key=image_api_key.strip(),size="1024x1536" if fmt=="Shorts (9:16)" else "1536x1024")
        for i,sc in enumerate(scenes):
            progress(0.3+0.45*(i+1)/max(1,len(scenes)),desc=f"Animating scene {i+1}/{len(scenes)}")
            if image_provider:
                art_path=project/f"artwork_{i+1:03}.png"
                visual_prompt=(f"{style_prefix}; cinematic documentary illustration; {sc['visual_prompt']}; "
                              "no text, no captions, no watermark, visually coherent scene")
                image_provider.generate(visual_prompt,art_path,reference=reference if reference else None)
                img=Image.open(art_path).convert("RGB").resize((W,H),Image.Resampling.LANCZOS)
            else:
                img=Image.new("RGB",(W,H),(20,25,38))
                if reference:
                    ref=Image.open(reference).convert("RGB")
                    ref.thumbnail((int(W*.7),int(H*.62)))
                    img.paste(ref,((W-ref.width)//2,(H-ref.height)//3))
            d=ImageDraw.Draw(img)
            # Text card is only used when no image provider is configured.
            try: font=ImageFont.truetype("DejaVuSans-Bold.ttf",max(24,int(W*.035)))
            except: font=ImageFont.load_default()
            if not image_provider:
                text=sc["narration"]
                words=text.split(); lines=[]; line=""
                for word in words:
                    if len(line+" "+word)>38: lines.append(line); line=word
                    else: line=(line+" "+word).strip()
                if line: lines.append(line)
                y=int(H*.72)
                for ln in lines[:5]:
                    box=d.textbbox((0,0),ln,font=font); d.text(((W-(box[2]-box[0]))//2,y),ln,font=font,fill="white",stroke_width=1,stroke_fill=(5,5,5)); y+=int(W*.05)
            d.rectangle((int(W*.06),int(H*.06),int(W*.94),int(H*.065)),fill=(60,190,210))
            still=project/f"scene_{i+1:03}.png"; img.save(still)
            from engines.animation_engine import animate_image
            clip=project/f"scene_{i+1:03}.mp4"
            dur=max(.8,sc["end"]-sc["start"])
            animate_image(still,clip,dur,W,H,"push" if i%2==0 else "pan")
            scene_files.append(clip)
        progress(0.78,desc="Generating subtitles and audio mix")
        srt=project/"captions.srt"; write_srt(transcript["segments"],srt)
        mixed=project/"audio_mix.m4a"; mix_audio(audio,mixed)
        progress(0.88,desc="Rendering final MP4")
        out=OUTPUTS/f"{Path(audio).stem}_{'short' if 'Shorts' in fmt else 'long'}.mp4"
        from engines.rendering_engine import render
        render(scene_files,mixed,out,srt if burn_subs else None,vertical="Shorts" in fmt)
        qc=inspect_mp4(out)
        report={"audio":info,"scene_count":len(scenes),"mp4_qc":qc,"visual_mode":"AI-generated scene artwork + Ken Burns motion" if image_provider else "2D Ken Burns motion + narration cards/reference image","image_provider":"OpenAI-compatible Images API" if image_provider else "not configured","note":"Scene artwork was generated via API." if image_provider else "Generative scene artwork provider is not configured; narration cards are used."}
        reportpath=project/"production_report.json"; reportpath.write_text(json.dumps(report,indent=2),encoding="utf-8")
        progress(1,desc="Complete")
        return str(out),str(reportpath),f"Finished: {len(scenes)} scenes | {qc.get('duration','?')} sec. QC: {qc.get('ok')}"
    except Exception as e:
        traceback.print_exc()
        raise gr.Error(f"Production failed: {e}")

# ---- AutoTube Ultimate unified dashboard -------------------------------------------------
def plan_script(script, style, max_words):
    from engines.story_pacing import plan_storyboard
    import json, tempfile
    if not script or not script.strip(): raise gr.Error("Paste a narration script first.")
    scenes=plan_storyboard(script,visual_style=style,max_words_per_scene=int(max_words))
    path=Path(tempfile.mkdtemp(prefix="autotube_storyboard_"))/"storyboard.json"
    path.write_text(json.dumps(scenes,indent=2,ensure_ascii=False),encoding="utf-8")
    preview="\n\n".join(f"SCENE {x['scene_id']} | {x['start']}–{x['end']} sec\n{x['narration']}\nVISUAL: {x['visual_prompt']}" for x in scenes)
    return preview,str(path),f"Planned {len(scenes)} scenes · estimated runtime {scenes[-1]['end']:.1f}s"

def prepare_rig(source, regions_json, remove_bg, progress=gr.Progress()):
    import json, shutil, tempfile, zipfile
    from PIL import Image, ImageDraw
    from engines.auto_rigging import extract_parts, remove_background, validate_rig_folder
    if not source: raise gr.Error("Upload a character sheet/image first.")
    root=Path(tempfile.mkdtemp(prefix="autotube_rig_")); working=root/"character.png"
    shutil.copy2(source,working)
    if remove_bg:
        progress(.15,desc="Removing background (rembg required)")
        transparent=root/"character_transparent.png"
        remove_background(working,transparent); working=transparent
    try: regions=json.loads(regions_json)
    except Exception as e: raise gr.Error(f"Regions JSON is invalid: {e}")
    progress(.45,desc="Extracting overlapping body-part layers")
    folder=root/"rig"; manifest=extract_parts(working,folder,regions,padding=12)
    errors=validate_rig_folder(folder)
    names=[n for n in manifest['parts'] if (folder/f"{n}.png").exists()]
    thumbs=[]
    for name in names:
        im=Image.open(folder/f"{name}.png").convert("RGBA"); im.thumbnail((280,280))
        tile=Image.new("RGB",(320,330),(38,42,52)); tile.paste(im,((320-im.width)//2,8),im)
        ImageDraw.Draw(tile).text((10,305),name,fill="white"); thumbs.append(tile)
    cols=3; rows=max(1,(len(thumbs)+cols-1)//cols); sheet=Image.new("RGB",(cols*320,rows*330),(20,22,28))
    for i,t in enumerate(thumbs): sheet.paste(t,((i%cols)*320,(i//cols)*330))
    preview=root/"rig_preview.jpg"; sheet.save(preview,quality=90)
    archive=root/"character_rig.zip"
    with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED) as z:
        for f in folder.iterdir(): z.write(f,f.name)
    progress(1,desc="Rig package ready")
    status="Rig assets prepared. Review crops, overlap, and pivots in rig_manifest.json."+(" Validation warnings: "+"; ".join(errors) if errors else " Required layers present.")
    return str(preview),str(archive),status

def run_qc(video_path, subtitle_path):
    from engines.quality_control import inspect_video
    if not video_path: raise gr.Error("Upload/select an MP4 to inspect.")
    report=inspect_video(video_path,subtitles=subtitle_path if subtitle_path else None)
    out=Path(tempfile.mkdtemp(prefix="autotube_qc_"))/"quality_control.json"
    out.write_text(json.dumps(report,indent=2),encoding="utf-8")
    return report,str(out)

DEFAULT_REGIONS='''{
  "torso": [0.30, 0.28, 0.70, 0.68],
  "head": [0.34, 0.04, 0.66, 0.32],
  "left_arm": [0.08, 0.28, 0.38, 0.62],
  "right_arm": [0.62, 0.28, 0.92, 0.62],
  "left_leg": [0.28, 0.62, 0.49, 0.98],
  "right_leg": [0.51, 0.62, 0.72, 0.98]
}'''

MOBILE_CSS = """
/* Mobile-first touch layout for iPhone / narrow screens */
html, body { -webkit-text-size-adjust: 100%; }
.gradio-container { max-width: 100% !important; padding: 10px !important; }
.gradio-container h1 { font-size: clamp(1.35rem, 6vw, 2.1rem) !important; line-height: 1.15; }
.gradio-container h2, .gradio-container h3 { font-size: clamp(1.05rem, 4.5vw, 1.5rem) !important; }
button, input, textarea, select { font-size: 16px !important; }
button { min-height: 44px !important; touch-action: manipulation; }
textarea { min-height: 130px; }
@media (max-width: 600px) {
  .gradio-container { padding: 8px !important; }
  .tabs { gap: 4px !important; }
  button { width: 100%; }
  .wrap { flex-wrap: wrap !important; }
  video { width: 100% !important; }
}
"""

with gr.Blocks(title="AutoTube Ultimate · Mobile",theme=gr.themes.Soft(),css=MOBILE_CSS) as demo:
    gr.Markdown("# 🎬 AutoTube Ultimate\n### One workspace · script, voiceover, artwork, rigging, animation, export & QC")
    gr.Markdown("**Honest capability note:** narration-card visuals and camera animation work locally. AI scene artwork needs a compatible image API/key. Character rig extraction is semi-automatic: you set crop regions and inspect joints/pivots. Advanced generative video/automatic anatomical rigging are not bundled capabilities.")
    with gr.Tab("🚀 Video Production"):
        gr.Markdown("### Voiceover → documentary MP4")
        with gr.Row():
            with gr.Column():
                audio=gr.Audio(label="Voiceover (MP3/WAV)",type="filepath")
                ref=gr.Image(label="Optional character / visual reference",type="filepath")
                fmt=gr.Radio(["Shorts (9:16)","Long-form (16:9)"],value="Long-form (16:9)",label="Video format")
                style=gr.Dropdown(["2D Cartoon","Storybook 2D","Comic 2D","Cinematic wildlife documentary"],value="Cinematic wildlife documentary",label="Animation style")
                quality=gr.Dropdown(["Draft","Standard","High"],value="Standard",label="Production quality")
                subs=gr.Checkbox(value=True,label="Burn subtitles into video")
                image_key=gr.Textbox(label="Image API key (optional)",type="password",placeholder="API key for generated scene artwork")
                start=gr.Button("🚀 START PRODUCTION",variant="primary")
            with gr.Column():
                video=gr.Video(label="Final MP4")
                report=gr.File(label="Production report")
                status=gr.Textbox(label="Production status",interactive=False)
        start.click(production,[audio,ref,fmt,style,quality,subs,image_key],[video,report,status])
    with gr.Tab("📝 Script → Storyboard"):
        gr.Markdown("Paste a script to split it into editable scene beats with estimated timing and image prompts.")
        script=gr.Textbox(label="Narration script",lines=14,placeholder="Paste your documentary script...")
        with gr.Row():
            pace_style=gr.Textbox(value="Cinematic wildlife documentary",label="Visual style")
            max_words=gr.Slider(12,70,value=35,step=1,label="Maximum words per scene")
        plan_btn=gr.Button("Generate storyboard",variant="primary")
        storyboard_preview=gr.Textbox(label="Storyboard preview",lines=16)
        storyboard_file=gr.File(label="Download storyboard JSON")
        plan_status=gr.Textbox(label="Planner status")
        plan_btn.click(plan_script,[script,pace_style,max_words],[storyboard_preview,storyboard_file,plan_status])
    with gr.Tab("🦴 Character Rig Studio"):
        gr.Markdown("Upload a character sheet. Define normalized crop boxes (x0,y0,x1,y1 from 0–1); overlap at shoulders, elbows and hips. Default boxes are only a starting template and must be adjusted for your character.")
        rig_source=gr.Image(label="Character image / transparent sheet",type="filepath")
        rig_regions=gr.Code(value=DEFAULT_REGIONS,language="json",label="Body-part crop regions JSON",lines=18)
        rig_remove=gr.Checkbox(label="Attempt background removal first (requires rembg installed)",value=False)
        rig_btn=gr.Button("Prepare rig layers",variant="primary")
        with gr.Row(): rig_preview=gr.Image(label="Extracted layer preview"); rig_zip=gr.File(label="Download character rig ZIP")
        rig_status=gr.Textbox(label="Rig status")
        rig_btn.click(prepare_rig,[rig_source,rig_regions,rig_remove],[rig_preview,rig_zip,rig_status])
        gr.Markdown("**Required output:** torso, head, left/right arms, left/right legs, `rig_manifest.json`. Tune pivots and joint overlap before expecting convincing motion. `rembg` is optional: `pip install rembg`.")
    with gr.Tab("🧪 Export Quality Control"):
        qc_video=gr.File(label="MP4 file")
        qc_srt=gr.File(label="Optional SRT subtitles")
        qc_btn=gr.Button("Inspect export",variant="primary")
        qc_result=gr.JSON(label="QC findings")
        qc_file=gr.File(label="Download QC report")
        qc_btn.click(run_qc,[qc_video,qc_srt],[qc_result,qc_file])
    gr.Markdown("### Local requirements\nPython 3.10+ recommended · FFmpeg installed and on PATH · install `requirements.txt`. Transcription downloads Whisper model weights on first run. Image generation APIs may incur usage charges.")

import os
demo.launch(server_name="0.0.0.0",server_port=int(os.environ.get("PORT", "7860")),share=False)
