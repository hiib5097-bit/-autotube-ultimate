# AutoTube v2.1 — Character Rig Preparation

- Added semi-automatic transparent PNG part extraction from editable normalized regions.
- Generates rig manifest with crop coordinates, pivots and layer order.
- Added rig-folder validation with actionable errors.
- Added optional `rembg` background-removal adapter (not bundled; install separately).
- Added tests for extraction, invalid regions and validation.

**Scope note:** Anatomical segmentation and pivot estimation are still manual/reviewed. This release does not claim one-click AI rigging.

Validation: 54 tests passed; Python compile check passed.
